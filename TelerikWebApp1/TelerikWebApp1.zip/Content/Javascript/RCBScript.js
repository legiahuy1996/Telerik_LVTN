﻿
var RCBS_EmpHeaderSearch_Company;
var RCBS_EmpHeaderSearch_Level1;
var RCBS_EmpHeaderSearch_Level2;
var RCBS_EmpHeaderSearch_Level3;
var RCBS_EmpHeaderSearch_Level4;
var RCBS_EmpHeaderSearch_Level5;
var RCBS_EmpHeaderSearch_Level6;
var RCBS_EmpHeaderSearch_Level7;
var RCBS_EmpHeaderSearch_Level8;
var RCBS_EmpHeaderSearch_Level9;

var RCBS_EmpHeaderSearchSI_Company;
var RCBS_EmpHeaderSearchSI_Level1;
var RCBS_EmpHeaderSearchSI_Level2;
var RCBS_EmpHeaderSearchSI_Level3;

var RCBS_EmpHeaderSearch1_Company;
var RCBS_EmpHeaderSearch1_Level1;
var RCBS_EmpHeaderSearch1_Level2;
var RCBS_EmpHeaderSearch1_Level3;
var RCBS_EmpHeaderSearch1_Level4;
var RCBS_EmpHeaderSearch1_Level5;
var RCBS_EmpHeaderSearch1_Level6;
var RCBS_EmpHeaderSearch1_Level7;
var RCBS_EmpHeaderSearch1_Level8;
var RCBS_EmpHeaderSearch1_Level9;

//BaoNTQ: 18/07/2012
var RCBS_OrgSelectSimple_H1_cboCompany;
var RCBS_OrgSelectSimple_H1_cboLevel1;
var RCBS_OrgSelectSimple_H1_cboLevel2;
var RCBS_OrgSelectSimple_H1_cboLevel3;

//SonNT:11/07/2012
var RCBS_TrPlanHeader1_Company;
var RCBS_TrPlanHeader1_Level1;
var RCBS_TrPlanHeader1_Level2;
var RCBS_TrPlanHeader1_Level3;
var RCBS_TrPlanHeader1_Level4;
var RCBS_TrPlanHeader1_Level5;
var RCBS_TrPlanHeader1_Level6;
var RCBS_TrPlanHeader1_Level7;
var RCBS_TrPlanHeader1_Level8;
var RCBS_TrPlanHeader1_Level9;
//tuan tao header chi co 9 cap
var RCBS_OrgSelectSimple1_Company;
var RCBS_OrgSelectSimple1_Level1;
var RCBS_OrgSelectSimple1_Level2;
var RCBS_OrgSelectSimple1_Level3;
var RCBS_OrgSelectSimple1_Level4;
var RCBS_OrgSelectSimple1_Level5;
var RCBS_OrgSelectSimple1_Level6;
var RCBS_OrgSelectSimple1_Level7;
var RCBS_OrgSelectSimple1_Level8;
var RCBS_OrgSelectSimple1_Level9;
//
var RCBS_TrCourseHeader1_Company;
var RCBS_TrCourseHeader1_Level1;
var RCBS_TrCourseHeader1_Level2;
var RCBS_TrCourseHeader1_Level3;
var RCBS_TrCourseHeader1_Level4;
var RCBS_TrCourseHeader1_Level5;
var RCBS_TrCourseHeader1_Level6;
var RCBS_TrCourseHeader1_Level7;
var RCBS_TrCourseHeader1_Level8;
var RCBS_TrCourseHeader1_Level9;

//TruyenNG:27/09/2011
var RCBS_EmpHeaderSearchReport_Company;
var RCBS_EmpHeaderSearchReport_Level1;
var RCBS_EmpHeaderSearchReport_Level2;
var RCBS_EmpHeaderSearchReport_Level3;

var RCBS_EmpSearchSimple_Company;
var RCBS_EmpSearchSimple_Level1;
var RCBS_EmpSearchSimple_Level2;
var RCBS_EmpSearchSimple_Level3;

var RCBS_EmpSearchSimple3_Company;
var RCBS_EmpSearchSimple3_Level1;
var RCBS_EmpSearchSimple3_Level2;
var RCBS_EmpSearchSimple3_Level3;
var RCBS_EmpSearchSimple3_Level4;
var RCBS_EmpSearchSimple3_Level5;
var RCBS_EmpSearchSimple3_Level6;
var RCBS_EmpSearchSimple3_Level7;
var RCBS_EmpSearchSimple3_Level8;
var RCBS_EmpSearchSimple3_Level9;

var RCBS_NhomChiPhiHanhChinh;
var RCBS_ChiPhiHanhChinh;
//24/12/2012
var RCBS_LoaiSanPham;
var RCBS_CongDoanSX;
//:28/10/2011
var RCBS_NhomChucDanhDuAn;
var RCBS_NhomChucDanhDuAnCopy;
var RCBS_ChucDanhDuAn;
var RCBS_ChucDanhDuAnCopy;
var RCBS_DuAnPT;

var RCBS_ProjectVersionID;

var RCBS_ProfessionalLevelType
var RCBS_TrainingRange;
//
var RCBS_SkillGroup;
var RCBS_SkillType;
var RCBS_EmpSkill;

var RCBS_BangLuongMem;
var RCBS_ThangLuongMem;
var RCBS_NgachLuongMem;
var RCBS_BacLuongMem;
//Phat Sinh Tu Du An Traphaco
var RCBS_LienChiDoan;
var RCBS_ChiDoan;
var RCBS_PhanDoan;
//20120103:PVGAS
var RCBS_BangLuong;

//End
var RCBS_LSOfficeTypeID;
var RCBS_Company;
var RCBS_Company_;
var RCBS_CompanyAll;
var RCBS_Level1;
var RCBS_Level1_;
var RCBS_Level1All;
var RCBS_Level2;
var RCBS_Level2_;
var RCBS_Level2All;
var RCBS_Level3;
var RCBS_Level3_;
var RCBS_Level3All;
var RCBS_P_Province;
var RCBS_P_District;
var RCBS_P_Ward;
var RCBS_T_Ward;

var RCBS_T_Province;
var RCBS_T_District;
var RCBS_Bank;
var RCBS_Bank_Second;
var RCBS_BankBranch;
var RCBS_BankBranch_Second;
var RCBS_TemplateLinkServer;
var RCBS_TypeDataLinkServer;
//DanL : 20111103 ==> Thêm combo Loại nhóm người dùng + Nhóm người dùng
var RCBS_UserType;
var RCBS_UserGroup;
//DanL : 20111124 ==> Thêm combo Nhóm JobCode + JobCode + Loại công việc
var RCBS_JobCodeGroup;
var RCBS_JobCode;
var RCBS_JobType;
var RCBS_APPYear;
var RCBS_APPYear_;
var RCBS_APPPeriod;
var RCBS_APPPeriod_;
var RCBS_OpenAPPPeriod;
var RCBS_APPSubject;

var RCBS_Nam;
var RCBS_APPKyDanhGiaHanhViID;

var RCBS_NamKH;
var RCBS_KyKeHoachPhatTrienBanThanID;
//DanL : 20111129 ==> Thêm combo Chức vụ + Chức danh
var RCBS_JobFunction;
var RCBS_JobTitle;
//DanL : 20130515 ==> Thêm combo Dự án + Lệnh sản xuất
var RCBS_DuAn;
var RCBS_LenhSanXuat;
//SonNT: 20120618 ==> Thêm combo Loại BHLĐ + Nội dung BHLĐ
var RCBS_LoaiBHLD;
var RCBS_NoiDungBHLD;

//SonNT: 20120711 ==> Thêm combo Chương trình đào tạo + khóa đào tạo
var RCBS_TrainingField;
var RCBS_TrainingTopic;
//lucnns
var RCBS_TrainingField2140;
var RCBS_TrainingTopic2140;
var RCBS_TrainingField_;
var RCBS_TrainingTopic_;

// Lam begin 
var RCBS_LoaiTaiSan;
var RCBS_NhomTaiSan;
var RCBS_CCDC;
var RCBS_CongTy;
var RCBS_CongTyAll;
var RCBS_DonVi;
var RCBS_DonViAll;
var RCBS_PhongBan;
var RCBS_PhongBanAll;
var RCBS_ToNhom;
var RCBS_ToNhomAll;
var RCBS_Level4;
var RCBS_Level5;
var RCBS_Level6;
var RCBS_Level7;
var RCBS_Level8;
var RCBS_Level9;
var RCBS_MonHoc;
var RCBS_LopHoc;
var RCBS_GiangVien;
var RCBS_ChuongTrinh;
var RCBS_KhoaDT;
var RCBS_LoaiNguoiDung;
var RCBS_CopyPer;
var RCBS_GroupID;
var RCBS_UserID;
var RCBS_dlModule;

var RCBS_ThangLuong;
var RCBS_NgachLuong;
var RCBS_BacLuong;

var RCBS_LSTrainingSubjectID;
var RCBS_LSTrainingSubjectIDCopy;
var RCBS_cboClassCopy;

var RCBS_BoMauBH;
var RCBS_LoaiNguonBaoBH;
var RCBS_NguonBaoBH;
var RCBS_BacLuongSTB;
var RCBS_Date;
var RCBS_RERecruitTypeID;
var RCBS_NguoiYeuCau;
var RCBS_P_District_;
var RCBS_T_District_;

var RCBS_LoaiNguonTuyenDung;
var RCBS_NguonTuyenDung;
// Lam end

//Bệnh viện
var RCBS_Hospital;
//Loại HĐ
var RCBS_ContractType;
//Quan hệ gia đình
var RCBS_Relationship;
//Hình thức luân chuyển
var RCBS_StatusChange;
//Loại nhân viên
var RCBS_LoaiNhanVien;
//DEmand
var RCBS_DemandAll;
//Project
var RCBS_Project;
//ProjectTournament
var RCBS_ProjectTournament;
//ProjectTournamentSubject
var RCBS_ProjectTournamentSubject;
//ProjectTournamentIntContent
var RCBS_ProjectTournamentIntContent;

//DanL : 20121211 ==> Thêm combo Nhóm công việc + Loại công việc
var RCBS_NhomCongViec;
var RCBS_LoaiCongViec;
//TrangNT: 20130305 
var RCBS_NhomNguyenNhanTNLD;
var RCBS_NguyenNhanTNLD;

var RCBS_NhomYeuToChanThuong;
var RCBS_YeuToChanThuong;

var RCBS_NhomBenhNgheNghiep;
var RCBS_BenhNgheNghiep;

var RCBS_PhanHe_DyNTmp;
var RCBS_TenBaoCao_DyNTmp;
var RCBS_LoaiThongTin_DyNTmp;

var RCBS_SIGroupType;
var RCBS_SIGroupType_Cap2;

var RCBS_HLevel1;
var RCBS_HLevel2;
var RCBS_HLevel3;
var RCBS_HLevel4;
var RCBS_HLevel5;
var RCBS_HLevel6;

var RCBS_Header_HLevel1;
var RCBS_Header_HLevel2;
var RCBS_Header_HLevel3;
var RCBS_Header_HLevel4;
var RCBS_Header_HLevel5;
var RCBS_Header_HLevel6;

// Khởi tạo các biến cho các related RadComboBox Cơ cấu
function InitRCB() {

    /* RCB EmpHeaderSearch */
    RCBS_EmpHeaderSearch_Company = $find("_ctl0_EmpHeaderSearch1_cboCompany");
    RCBS_EmpHeaderSearch_Level1 = $find("_ctl0_EmpHeaderSearch1_cboLevel1");
    RCBS_EmpHeaderSearch_Level2 = $find("_ctl0_EmpHeaderSearch1_cboLevel2");
    RCBS_EmpHeaderSearch_Level3 = $find("_ctl0_EmpHeaderSearch1_cboLevel3");
    RCBS_EmpHeaderSearch_Level4 = $find("_ctl0_EmpHeaderSearch1_cboLevel4ID");
    RCBS_EmpHeaderSearch_Level5 = $find("_ctl0_EmpHeaderSearch1_cboLevel5ID");
    RCBS_EmpHeaderSearch_Level6 = $find("_ctl0_EmpHeaderSearch1_cboLevel6ID");
    RCBS_EmpHeaderSearch_Level7 = $find("_ctl0_EmpHeaderSearch1_cboLevel7ID");
    RCBS_EmpHeaderSearch_Level8 = $find("_ctl0_EmpHeaderSearch1_cboLevel8ID");
    RCBS_EmpHeaderSearch_Level9 = $find("_ctl0_EmpHeaderSearch1_cboLevel9ID");
    /* End */

    /* RCB EmpHeaderSearchSI */
    RCBS_EmpHeaderSearchSI_Company = $find("_ctl0_EmpHeaderSearchSI1_cboCompany");
    RCBS_EmpHeaderSearchSI_Level1 = $find("_ctl0_EmpHeaderSearchSI1_cboLevel1");
    RCBS_EmpHeaderSearchSI_Level2 = $find("_ctl0_EmpHeaderSearchSI1_cboLevel2");
    RCBS_EmpHeaderSearchSI_Level3 = $find("_ctl0_EmpHeaderSearchSI1_cboLevel3");
    /* End */

    /* RCB EmpHeaderSearch1 */
    RCBS_EmpHeaderSearch1_Company = $find("_ctl0_EmpHeaderSearch11_cboCompany");
    RCBS_EmpHeaderSearch1_Level1 = $find("_ctl0_EmpHeaderSearch11_cboLevel1");
    RCBS_EmpHeaderSearch1_Level2 = $find("_ctl0_EmpHeaderSearch11_cboLevel2");
    RCBS_EmpHeaderSearch1_Level3 = $find("_ctl0_EmpHeaderSearch11_cboLevel3");
    RCBS_EmpHeaderSearch1_Level4 = $find("_ctl0_EmpHeaderSearch11_cboLevel4ID");
    RCBS_EmpHeaderSearch1_Level5 = $find("_ctl0_EmpHeaderSearch11_cboLevel5ID");
    RCBS_EmpHeaderSearch1_Level6 = $find("_ctl0_EmpHeaderSearch11_cboLevel6ID");
    RCBS_EmpHeaderSearch1_Level7 = $find("_ctl0_EmpHeaderSearch11_cboLevel7ID");
    RCBS_EmpHeaderSearch1_Level8 = $find("_ctl0_EmpHeaderSearch11_cboLevel8ID");
    RCBS_EmpHeaderSearch1_Level9 = $find("_ctl0_EmpHeaderSearch11_cboLevel9ID");

    /* End */

    /* RCB TrPlanHeader1 */
    RCBS_TrPlanHeader1_Company = $find("_ctl0_TrPlanHeader1_cboCompany");
    RCBS_TrPlanHeader1_Level1 = $find("_ctl0_TrPlanHeader1_cboLevel1");
    RCBS_TrPlanHeader1_Level2 = $find("_ctl0_TrPlanHeader1_cboLevel2");
    RCBS_TrPlanHeader1_Level3 = $find("_ctl0_TrPlanHeader1_cboLevel3");
    RCBS_TrPlanHeader1_Level4 = $find("_ctl0_TrPlanHeader1_cboLevel4ID");
    RCBS_TrPlanHeader1_Level5 = $find("_ctl0_TrPlanHeader1_cboLevel5ID");
    RCBS_TrPlanHeader1_Level6 = $find("_ctl0_TrPlanHeader1_cboLevel6ID");
    RCBS_TrPlanHeader1_Level7 = $find("_ctl0_TrPlanHeader1_cboLevel7ID");
    RCBS_TrPlanHeader1_Level8 = $find("_ctl0_TrPlanHeader1_cboLevel8ID");
    RCBS_TrPlanHeader1_Level9 = $find("_ctl0_TrPlanHeader1_cboLevel9ID");

    //tuan RCBS_OrgSelectSimple1_Company
    RCBS_OrgSelectSimple1_Company = $find("_ctl0_OrgSelectSimple1_cboCompany");
    RCBS_OrgSelectSimple1_Level1 = $find("_ctl0_OrgSelectSimple1_cboLevel1");
    RCBS_OrgSelectSimple1_Level2 = $find("_ctl0_OrgSelectSimple1_cboLevel2");
    RCBS_OrgSelectSimple1_Level3 = $find("_ctl0_OrgSelectSimple1_cboLevel3");
    RCBS_OrgSelectSimple1_Level4 = $find("_ctl0_OrgSelectSimple1_cboLevel4ID");
    RCBS_OrgSelectSimple1_Level5 = $find("_ctl0_OrgSelectSimple1_cboLevel5ID");
    RCBS_OrgSelectSimple1_Level6 = $find("_ctl0_OrgSelectSimple1_cboLevel6ID");
    RCBS_OrgSelectSimple1_Level7 = $find("_ctl0_OrgSelectSimple1_cboLevel7ID");
    RCBS_OrgSelectSimple1_Level8 = $find("_ctl0_OrgSelectSimple1_cboLevel8ID");
    RCBS_OrgSelectSimple1_Level9 = $find("_ctl0_OrgSelectSimple1_cboLevel9ID");
    /* RCB TrPlanHeader1 */


    RCBS_TrCourseHeader1_Company = $find("_ctl0_TrCourseHeader1_cboCompany");
    RCBS_TrCourseHeader1_Level1 = $find("_ctl0_TrCourseHeader1_cboLevel1");
    RCBS_TrCourseHeader1_Level2 = $find("_ctl0_TrCourseHeader1_cboLevel2");
    RCBS_TrCourseHeader1_Level3 = $find("_ctl0_TrCourseHeader1_cboLevel3");
    RCBS_TrCourseHeader1_Level4 = $find("_ctl0_TrCourseHeader1_cboLevel4ID");
    RCBS_TrCourseHeader1_Level5 = $find("_ctl0_TrCourseHeader1_cboLevel5ID");
    RCBS_TrCourseHeader1_Level6 = $find("_ctl0_TrCourseHeader1_cboLevel6ID");
    RCBS_TrCourseHeader1_Level7 = $find("_ctl0_TrCourseHeader1_cboLevel7ID");
    RCBS_TrCourseHeader1_Level8 = $find("_ctl0_TrCourseHeader1_cboLevel8ID");
    RCBS_TrCourseHeader1_Level9 = $find("_ctl0_TrCourseHeader1_cboLevel9ID");

    /* End */

    /* RCB OrgSelectSimple_H1 */
    RCBS_OrgSelectSimple_H1_cboCompany = $find("_ctl0_OrgSelectSimple_H1_cboCompany");
    RCBS_OrgSelectSimple_H1_cboLevel1 = $find("_ctl0_OrgSelectSimple_H1_cboLevel1");
    RCBS_OrgSelectSimple_H1_cboLevel2 = $find("_ctl0_OrgSelectSimple_H1_cboLevel2");
    RCBS_OrgSelectSimple_H1_cboLevel3 = $find("_ctl0_OrgSelectSimple_H1_cboLevel3");
    /* End */

    /* RCB EmpHeaderSearchReport */
    RCBS_EmpHeaderSearchReport_Company = $find("_ctl0_EmpHeaderSearchReport1_cboCompany");
    RCBS_EmpHeaderSearchReport_Level1 = $find("_ctl0_EmpHeaderSearchReport1_cboLevel1");
    RCBS_EmpHeaderSearchReport_Level2 = $find("_ctl0_EmpHeaderSearchReport1_cboLevel2");
    RCBS_EmpHeaderSearchReport_Level3 = $find("_ctl0_EmpHeaderSearchReport1_cboLevel3");

    RCBS_EmpSearchSimple_Company = $find("_ctl0_EmpSearchSimple1_cboCompany");
    RCBS_EmpSearchSimple_Level1 = $find("_ctl0_EmpSearchSimple1_cboLevel1");
    RCBS_EmpSearchSimple_Level2 = $find("_ctl0_EmpSearchSimple1_cboLevel2");
    RCBS_EmpSearchSimple_Level3 = $find("_ctl0_EmpSearchSimple1_cboLevel3");

    RCBS_EmpSearchSimple3_Company = $find("_ctl0_EmpSearchSimple3_cboCompany");
    RCBS_EmpSearchSimple3_Level1 = $find("_ctl0_EmpSearchSimple3_cboLevel1");
    RCBS_EmpSearchSimple3_Level2 = $find("_ctl0_EmpSearchSimple3_cboLevel2");
    RCBS_EmpSearchSimple3_Level3 = $find("_ctl0_EmpSearchSimple3_cboLevel3");
    RCBS_EmpSearchSimple3_Level4 = $find("_ctl0_EmpSearchSimple3_cboLevel4ID");
    RCBS_EmpSearchSimple3_Level5 = $find("_ctl0_EmpSearchSimple3_cboLevel5ID");
    RCBS_EmpSearchSimple3_Level6 = $find("_ctl0_EmpSearchSimple3_cboLevel6ID");
    RCBS_EmpSearchSimple3_Level7 = $find("_ctl0_EmpSearchSimple3_cboLevel7ID");
    RCBS_EmpSearchSimple3_Level8 = $find("_ctl0_EmpSearchSimple3_cboLevel8ID");
    RCBS_EmpSearchSimple3_Level9 = $find("_ctl0_EmpSearchSimple3_cboLevel9ID");
    /* End */

    RCBS_LSOfficeTypeID = $find("_ctl0_cboLSOfficeTypeID");
    RCBS_Company = $find("_ctl0_cboCompanyID");
    RCBS_Company_ = $find("_ctl0_cboCompanyID_");
    RCBS_CompanyAll = $find("_ctl0_cboCompanyAllID");
    RCBS_Level1 = $find("_ctl0_cboLevel1ID");
    RCBS_Level1_ = $find("_ctl0_cboLevel1ID_");
    RCBS_Level1All = $find("_ctl0_cboLevel1AllID");
    RCBS_Level2 = $find("_ctl0_cboLevel2ID");
    RCBS_Level2_ = $find("_ctl0_cboLevel2ID_");
    RCBS_Level2All = $find("_ctl0_cboLevel2AllID");
    RCBS_Level3 = $find("_ctl0_cboLevel3ID");
    RCBS_Level3_ = $find("_ctl0_cboLevel3ID_");
    RCBS_Level3All = $find("_ctl0_cboLevel3AllID");
    RCBS_P_Province = $find("_ctl0_cboP_LSProvinceID");
    RCBS_P_District = $find("_ctl0_cboP_District");
    RCBS_P_Ward = $find("_ctl0_cboP_Ward");
    RCBS_T_Ward = $find("_ctl0_cboT_Ward");
    
    RCBS_T_Province = $find("_ctl0_cboT_LSProvinceID");
    RCBS_T_District = $find("_ctl0_cboT_District");
    RCBS_Bank = $find("_ctl0_cboLSBankID");
    RCBS_BankBranch = $find("_ctl0_cboLSBankBranchID");
    RCBS_Bank_Second = $find("_ctl0_cboLSBankID_Second");
    RCBS_BankBranch_Second = $find("_ctl0_cboLSBankBranchID_Second");
    RCBS_TemplateLinkServer = $find("_ctl0_cboLSTemplateLinkServerID");
    RCBS_TypeDataLinkServer = $find("_ctl0_cboLSTypeDataLinkServerID");

    RCBS_NhomChiPhiHanhChinh = $find("_ctl0_cboLSNhomChiPhiHanhChinhID");
    RCBS_ChiPhiHanhChinh = $find("_ctl0_cboLSChiPhiHanhChinhID");

    RCBS_LoaiSanPham = $find("_ctl0_cboLSLoaiSanPhamID");
    RCBS_CongDoanSX = $find("_ctl0_cboLSCongDoanSXID");

    RCBS_NhomChucDanhDuAn = $find("_ctl0_cboNhomChucDanh");
    RCBS_ChucDanhDuAn = $find("_ctl0_cboChucDanhDuAn");
    RCBS_NhomChucDanhDuAnCopy = $find("_ctl0_cboNhomChucDanhCopy");
    RCBS_ChucDanhDuAnCopy = $find("_ctl0_cboChucDanhDuAnCopy");
    
    RCBS_ProjectVersionID = $find("_ctl0_cboProjectVersionID");
    
    RCBS_DuAnPT = $find("_ctl0_cboDuAn");
    RCBS_ProjectVersion = $find("_ctl0_cboProjectVersionID");

    //Nhóm Kỹ năng + Loại Kỹ năng
    RCBS_SkillGroup = $find("_ctl0_cboLSSkillGroupID");
    RCBS_SkillType = $find("_ctl0_cboLSSkillTypeID");
    RCBS_EmpSkill = $find("_ctl0_cboLSEmpSkillID");

    RCBS_ProfessionalLevelType = $find("_ctl0_cboLSProfessionalLevelTypeID");
    RCBS_TrainingRange = $find("_ctl0_cboLSTrainingRangeID");

    //Loại nhóm người dùng + Nhóm người dùng
    RCBS_UserType = $find("_ctl0_cboLoaiNguoiDung");
    RCBS_UserGroup = $find("_ctl0_cboNhomNguoiDung");

    //Nhóm JobCode + JobCode + Loại công việc
    RCBS_JobCodeGroup = $find("_ctl0_cboLSJobCodeGroupID");
    RCBS_JobCode = $find("_ctl0_cboLSJobCodeID");
    RCBS_JobType = $find("_ctl0_cboLSJobTypeID");

    //Dự án + Lệnh sản xuất
    RCBS_DuAn = $find("_ctl0_cboLSProjectList");
    RCBS_LenhSanXuat = $find("_ctl0_cboLSLenhSanXuat");

    //Năm + Kỳ đánh giá theo năm + Đối tượng đánh giá theo kỳ
    RCBS_APPYear = $find("_ctl0_cboYear");
    RCBS_APPYear_ = $find("_ctl0_cboYear_");
    RCBS_APPPeriod = $find("_ctl0_cboAPPPeriod");
    RCBS_APPPeriod_ = $find("_ctl0_cboAPPPeriod_");
    RCBS_OpenAPPPeriod = $find("_ctl0_cboOpenAPPPeriod");
    RCBS_APPSubject = $find("_ctl0_cboAPPSubject");

    RCBS_Nam = $find("_ctl0_cboNam");
    RCBS_APPKyDanhGiaHanhViID = $find("_ctl0_cboAPPKyDanhGiaHanhViID");
    
    RCBS_NamKH = $find("_ctl0_cboNamKH");
    RCBS_KyKeHoachPhatTrienBanThanID = $find("_ctl0_cboKyKeHoachPhatTrienBanThanID");
    
    //Chức vụ + Chức danh
    RCBS_JobFunction = $find("_ctl0_cboLSChucVuID");
    RCBS_JobTitle = $find("_ctl0_cboLSJobTitleID_Related");

    //Nhóm + Loại công việc
    RCBS_NhomCongViec = $find("_ctl0_cboLSNhomNoiDungCVID");
    RCBS_LoaiCongViec = $find("_ctl0_cboLSLoaiNoiDungCVID");

    //Nhóm + Nguyên nhân TNLĐ
    RCBS_NhomNguyenNhanTNLD = $find("_ctl0_cboLSNhomNguyenNhanTNLDID");
    RCBS_NguyenNhanTNLD = $find("_ctl0_cboLSNguyenNhanTNLDID");

    //Nhóm + Yếu tố chấn thương
    RCBS_NhomYeuToChanThuong = $find("_ctl0_cboLSNhomYeuToChanThuongID");
    RCBS_YeuToChanThuong = $find("_ctl0_cboLSYeuToChanThuongID");

    //Nhóm + Bệnh nghề nghiệp
    RCBS_NhomBenhNgheNghiep = $find("_ctl0_cboLSNhomBenhNgheNghiepID");
    RCBS_BenhNgheNghiep = $find("_ctl0_cboLSBenhNgheNghiepID");

    //
    RCBS_PhanHe_DyNTmp = $find("_ctl0_cboPhanHe_DyNTmp");
    RCBS_TenBaoCao_DyNTmp = $find("_ctl0_cboTenBaoCao_DyNTmp");
    RCBS_LoaiThongTin_DyNTmp = $find("_ctl0_cboLoaiThongTin_DyNTmp");

    //RCBS_SIGroupType
    RCBS_SIGroupType = $find("_ctl0_cboSIGroupType");
    RCBS_SIGroupType_Cap2 = $find("_ctl0_cboSIGroupType_Cap2");

    RCBS_LoaiTaiSan = $find("_ctl0_cboLoaiTaiSan");
    RCBS_NhomTaiSan = $find("_ctl0_cboNhomCCDC");
    RCBS_CCDC = $find("_ctl0_cboVPP")

    //Loại BHLD + Nội dung BHLD
    RCBS_LoaiBHLD = $find("_ctl0_cboLoaiBHLD");
    RCBS_NoiDungBHLD = $find("_ctl0_cboNoiDungBHLD");

    //TrainingField + TrainingTopic for TrPlanHeader1
    RCBS_TrainingField = $find("_ctl0_TrPlanHeader1_cboLSTrainingFieldID");
    RCBS_TrainingTopic = $find("_ctl0_TrPlanHeader1_cboLSTrainingTopicID");
    RCBS_TrainingField2140 = $find("_ctl0_cboLSTrainingFieldID");
    RCBS_TrainingTopic2140 = $find("_ctl0_cboLSTrainingTopicID");

    //TrainingField + TrainingTopic for TrCourseHeader1

    RCBS_TrainingField_ = $find("_ctl0_TrCourseHeader1_cboLSTrainingFieldID");
    RCBS_TrainingTopic_ = $find("_ctl0_TrCourseHeader1_cboLSTrainingTopicID");

    //Bệnh viện
    RCBS_Hospital = $find("_ctl0_cboHospital");
    //Loại HĐ
    RCBS_ContractType = $find("_ctl0_cboContractType");
    //Quan hệ gia đình
    RCBS_Relationship = $find("_ctl0_cboRelationship");
    //Hình thức luân chuyển
    RCBS_StatusChange = $find("_ctl0_cboStatusChange");
    //Loại nhân viên
    RCBS_LoaiNhanVien = $find("_ctl0_cboLoaiNhanVien");

    // Lamtv2 begin     
    RCBS_CongTy = $find("_ctl0_cboLSCompanyID")
    if (RCBS_CongTy == null) {
        if (RCBS_CongTy == null)
            RCBS_CongTy = $find("_ctl0_cboCompany_")
    }
    RCBS_CongTyAll = $find("_ctl0_cboCompanyAllID");

    RCBS_DonVi = $find("_ctl0_cboLSLevel1ID")
    if (RCBS_DonVi == null) {
        RCBS_DonVi = $find("_ctl0_cboLevel1");
        if (RCBS_DonVi == null)
            RCBS_DonVi = $find("_ctl0_cboLevel1_");
    }
    RCBS_DonViAll = $find("_ctl0_cboLevel1AllID");

    RCBS_PhongBan = $find("_ctl0_cboLSLevel2ID");
    if (RCBS_PhongBan == null) {
        RCBS_PhongBan = $find("_ctl0_cboLevel2");
        if (RCBS_PhongBan == null)
            RCBS_PhongBan = $find("_ctl0_cboLevel2_");
    }
    RCBS_PhongBanAll = $find("_ctl0_cboLevel2AllID");

    RCBS_ToNhom = $find("_ctl0_cboLSLevel3ID");
    if (RCBS_ToNhom == null) {
        RCBS_ToNhom = $find("_ctl0_cboLevel3");
        if (RCBS_ToNhom == null)
            RCBS_ToNhom = $find("_ctl0_cboLevel3_");
    }
    RCBS_ToNhomAll = $find("_ctl0_cboLevel3AllID");

    RCBS_Level4 = $find("_ctl0_cboLSLevel4IDAll");
    if (RCBS_Level4 == null) {
        RCBS_Level4 = $find("_ctl0_cboLevel4ID");
        if (RCBS_Level4 == null) {
            RCBS_Level4 = $find("_ctl0_cboLevel4");
            if (RCBS_Level4 == null)
                RCBS_Level4 = $find("_ctl0_cboLSLevel4ID");
        }
    }
    RCBS_Level5 = $find("_ctl0_cboLSLevel5IDAll");
    if (RCBS_Level5 == null) {
        RCBS_Level5 = $find("_ctl0_cboLevel5ID");
        if (RCBS_Level5 == null) {
            RCBS_Level5 = $find("_ctl0_cboLevel5");
            if (RCBS_Level5 == null)
                RCBS_Level5 = $find("_ctl0_cboLSLevel5ID");
        }
    }
    RCBS_Level6 = $find("_ctl0_cboLSLevel6IDAll");
    if (RCBS_Level6 == null) {
        RCBS_Level6 = $find("_ctl0_cboLevel6ID");
        if (RCBS_Level6 == null) {
            RCBS_Level6 = $find("_ctl0_cboLevel6");
            if (RCBS_Level6 == null)
                RCBS_Level6 = $find("_ctl0_cboLSLevel6ID");
        }
    }
    RCBS_Level7 = $find("_ctl0_cboLSLevel7IDAll");
    if (RCBS_Level7 == null) {
        RCBS_Level7 = $find("_ctl0_cboLevel7ID");
        if (RCBS_Level7 == null) {
            RCBS_Level7 = $find("_ctl0_cboLevel7");
            if (RCBS_Level7 == null)
                RCBS_Level7 = $find("_ctl0_cboLSLevel7ID");
        }
    }
    RCBS_Level8 = $find("_ctl0_cboLSLevel8IDAll");
    if (RCBS_Level8 == null) {
        RCBS_Level8 = $find("_ctl0_cboLevel8ID");
        if (RCBS_Level8 == null) {
            RCBS_Level8 = $find("_ctl0_cboLevel8");
            if (RCBS_Level8 == null)
                RCBS_Level8 = $find("_ctl0_cboLSLevel8ID");
        }
    }
    RCBS_Level9 = $find("_ctl0_cboLSLevel9IDAll");
    if (RCBS_Level9 == null) {
        RCBS_Level9 = $find("_ctl0_cboLevel9ID");
        if (RCBS_Level9 == null) {
            RCBS_Level9 = $find("_ctl0_cboLevel9");
            if (RCBS_Level9 == null)
                RCBS_Level9 = $find("_ctl0_cboLSLevel9ID");
        }
    }

    RCBS_MonHoc = $find("_ctl0_cboMonHoc")
    RCBS_LopHoc = $find("_ctl0_cboClass")
    RCBS_GiangVien = $find("_ctl0_cboGiangVienID")
    RCBS_ChuongTrinh = $find("_ctl0_cboChuongTrinh")
    RCBS_KhoaDT = $find("_ctl0_cboKhoaDT")
    RCBS_LoaiNguoiDung = $find("_ctl0_cboLoaiNguoiDung")
    RCBS_CopyPer = $find("_ctl0_cboCopyPer")
    RCBS_GroupID = $find("_ctl0_cboGroupID")
    RCBS_UserID = $find("_ctl0_cboUserID")
    RCBS_dlModule = $find("_ctl0_dlModule")

    RCBS_BangLuong = $find("_ctl0_cboLSBangLuongID");
    RCBS_ThangLuong = $find("_ctl0_cboThangLuong")
    RCBS_NgachLuong = $find("_ctl0_cboNgachLuong");
    RCBS_BacLuong = $find("_ctl0_cboBacLuong");

    RCBS_BangLuongMem = $find("_ctl0_cboLSBangLuongMemID");
    RCBS_ThangLuongMem = $find("_ctl0_cboThangLuongMem")
    RCBS_NgachLuongMem = $find("_ctl0_cboNgachLuongMem");
    RCBS_BacLuongMem = $find("_ctl0_cboBacLuongMem");

    RCBS_LienChiDoan = $find("_ctl0_cboLSLienChiDoanID")
    RCBS_ChiDoan = $find("_ctl0_cboLSChiDoanID");
    RCBS_PhanDoan = $find("_ctl0_cboLSPhanDoanID");

    RCBS_LSTrainingSubjectID = $find("_ctl0_cboLSTrainingSubjectID")
    RCBS_LSTrainingSubjectIDCopy = $find("_ctl0_cboLSTrainingSubjectIDCopy")
    RCBS_cboClassCopy = $find("_ctl0_cboClassCopy")
    RCBS_Date = $find("_ctl0_cboDate");
    RCBS_Date_To = $find("_ctl0_cboDate_To");
    RCBS_RERecruitTypeID = $find("_ctl0_cboRERecruitTypeID")
    RCBS_NguoiYeuCau = $find("_ctl0_cboNguoiYeuCau")
    RCBS_P_District_ = $find("_ctl0_cboP_District_");
    RCBS_T_District_ = $find("_ctl0_CboT_District_");

    // Lamtv2 end

    //TrangNT
    //debugger;
    RCBS_BoMauBH = $find("_ctl0_cboBoMauBH");
    RCBS_LoaiNguonBaoBH = $find("_ctl0_cboLoaiNguonBaoBH");
    RCBS_NguonBaoBH = $find("_ctl0_cboSource");
    RCBS_BacLuongSTB = $find("_ctl0_cboHeSoLuong");
    RCBS_LoaiNguonTuyenDung = $find("_ctl0_cboLoaiNguonTuyenDung");
    RCBS_NguonTuyenDung = $find("_ctl0_cboNguonTuyenDung");
    RCBS_DemandAll = $find("_ctl0_cboDemandIDAll");
    RCBS_Project = $find("_ctl0_cboProjectID");
    RCBS_ProjectTournament = $find("_ctl0_cboProjectTournamentID");
    RCBS_ProjectTournamentSubject = $find("_ctl0_cboTournamentSubjectID");
    RCBS_ProjectTournamentIntContent = $find("_ctl0_cboTournamentIntContentID");
    //quanbm2 cao cau hang ngang
    RCBS_HLevel1 = $find("_ctl0_cboLSHLevel1ID");
    RCBS_HLevel2 = $find("_ctl0_cboLSHLevel2ID");
    RCBS_HLevel3 = $find("_ctl0_cboLSHLevel3ID");
    RCBS_HLevel4 = $find("_ctl0_cboLSHLevel4ID");
    RCBS_HLevel5 = $find("_ctl0_cboLSHLevel5ID");
    RCBS_HLevel6 = $find("_ctl0_cboLSHLevel6ID");

    RCBS_Header_HLevel1 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel1ID");
    RCBS_Header_HLevel2 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel2ID");
    RCBS_Header_HLevel3 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel3ID");
    RCBS_Header_HLevel4 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel4ID");
    RCBS_Header_HLevel5 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel5ID");
    RCBS_Header_HLevel6 = $find("_ctl0_EmpHeaderSearch1_cboLSHLevel6ID");

}

// Lamtv2 begin :

// ### Clear ##### 


function ClearAllItemsRelatedRCB_NguoiYeuCau() { // lamtv2
    if (document.getElementById('_ctl0_txtYCTDCach2').value != "True")/*YCTD cach 2 ko can function nay*/
    {
        if (RCBS_NguoiYeuCau != null) {
            RCBS_NguoiYeuCau.set_text("");
            RCBS_NguoiYeuCau.clearItems();
        }
    }
}

function ClearAllItemsRelatedRCB_RERecruitTypeID(comboID) { // lamtv2

    if (comboID.indexOf("RERecruitTypeID") >= 0) {
        ClearAllItemsRelatedRCB_NguoiYeuCau();
    }
}

function ClearAllItemsRelatedRCB_Date() { // lamtv2
    if (RCBS_Date != null) {
        RCBS_Date.set_text("");
        RCBS_Date.clearItems();

        try {// form: diem danh
            document.getElementById('_ctl0_txtFromHour').value = "";
            document.getElementById('_ctl0_txtToHour').value = "";
            document.getElementById('_ctl0_txtHours').value = "";
        }
        catch (e) { }
    }
}

function ClearAllItemsRelatedRCB_Date_To() { // lamtv2
    if (RCBS_Date_To != null) {
        RCBS_Date_To.set_text("");
        RCBS_Date_To.clearItems();
    }
}

function ClearAllItemsRelatedRCB_cboClassCopy() { // lamtv2
    if (RCBS_cboClassCopy != null) {
        RCBS_cboClassCopy.set_text("");
        RCBS_cboClassCopy.clearItems();
    }
}

function ClearAllItemsRelatedRCB_LSTrainingSubjectID(comboID) { // lamtv2

    if (comboID.indexOf("LSTrainingSubjectIDCopy") >= 0)
        ClearAllItemsRelatedRCB_cboClassCopy();
    else if (comboID.indexOf("LSTrainingSubjectID") >= 0) {
        ClearAllItemsRelatedRCB_LopHoc();
        ClearAllItemsRelatedRCB_Date();
        ClearAllItemsRelatedRCB_Date_To();
    }
    else if (comboID.indexOf("cboClass") >= 0) {
        ClearAllItemsRelatedRCB_Date();
        ClearAllItemsRelatedRCB_Date_To();
    }
}

function ClearAllItemsRelatedRCB_BacLuong() { // lamtv2
    if (RCBS_BacLuong != null) {
        RCBS_BacLuong.set_text("");
        RCBS_BacLuong.clearItems();
    }
}
function ClearAllItemsRelatedRCB_BacLuongMem() { // TruyenNG
    if (RCBS_BacLuongMem != null) {
        RCBS_BacLuongMem.set_text("");
        RCBS_BacLuongMem.clearItems();
    }
}
function ClearAllItemsRelatedRCB_PhanDoan() { // TruyenNG
    if (RCBS_PhanDoan != null) {
        RCBS_PhanDoan.set_text("");
        RCBS_PhanDoan.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NgachLuong() { // lamtv2
    if (RCBS_NgachLuong != null) {
        RCBS_NgachLuong.set_text("");
        RCBS_NgachLuong.clearItems();
    }
}
function ClearAllItemsRelatedRCB_NgachLuongMem() {
    if (RCBS_NgachLuongMem != null) {
        RCBS_NgachLuongMem.set_text("");
        RCBS_NgachLuongMem.clearItems();
    }
}
function ClearAllItemsRelatedRCB_ChiDoan() {
    if (RCBS_ChiDoan != null) {
        RCBS_ChiDoan.set_text("");
        RCBS_ChiDoan.clearItems();
    }
}

function ClearAllItemsRelatedRCB_ThangLuong(comboID) { // lamtv2
    if (comboID.indexOf("ThangLuong") >= 0) {
        ClearAllItemsRelatedRCB_NgachLuong();
        ClearAllItemsRelatedRCB_BacLuong();
    }
    else if (comboID.indexOf("NgachLuong") >= 0 && comboID.indexOf("NgachLuongMem") < 0) {
        ClearAllItemsRelatedRCB_BacLuong();
    }

}
function ClearAllItemsRelatedRCB_ThangLuongMem(comboID) { // TruyenNG
    if (comboID.indexOf("ThangLuongMem") >= 0) {
        ClearAllItemsRelatedRCB_NgachLuongMem();
        ClearAllItemsRelatedRCB_BacLuongMem();
    }
    else if (comboID.indexOf("NgachLuongMem") >= 0) {
        ClearAllItemsRelatedRCB_BacLuongMem();
    }

}

function ClearAllItemsRelatedRCB_LienChiDoan(comboID) { // TruyenNG
    if (comboID.indexOf("LienChiDoan") >= 0) {
        ClearAllItemsRelatedRCB_ChiDoan();
        ClearAllItemsRelatedRCB_PhanDoan();
    }
    else if (comboID.indexOf("ChiDoan") >= 0) {
        ClearAllItemsRelatedRCB_PhanDoan();
    }

}

function ClearAllItemsRelatedRCB_dlModule() { // lamtv2
    if (RCBS_dlModule != null) {
        RCBS_dlModule.set_text("");
        RCBS_dlModule.clearItems();
    }
}

function ClearAllItemsRelatedRCB_UserID() { // lamtv2
    if (RCBS_UserID != null) {
        RCBS_UserID.set_text("");
        RCBS_UserID.clearItems();
    }
}

function ClearAllItemsRelatedRCB_GroupID(comboID) { // lamtv2

    if (comboID.indexOf("GroupID") >= 0) {
        ClearAllItemsRelatedRCB_UserID();
        ClearAllItemsRelatedRCB_dlModule();
    }
}

function ClearAllItemsRelatedRCB_CopyPer() { // lamtv2
    if (RCBS_CopyPer != null) {
        RCBS_CopyPer.set_text("");
        RCBS_CopyPer.clearItems();
    }
}

function ClearAllItemsRelatedRCB_LoaiNguoiDung(comboID) { // lamtv2
    if (comboID.indexOf("LoaiNguoiDung") >= 0) {
        ClearAllItemsRelatedRCB_CopyPer();
    }
}


function ClearAllItemsRelatedRCB_KhoaDT() {
    if (RCBS_KhoaDT != null) {
        RCBS_KhoaDT.set_text("");
        RCBS_KhoaDT.clearItems();
    }
}

function ClearAllItemsRelatedRCB_ChuongTrinh(comboID) {
    if (comboID.indexOf("cboChuongTrinh") >= 0) {
        ClearAllItemsRelatedRCB_KhoaDT();
        ClearAllItemsRelatedRCB_MonHoc();
    }
    else if (comboID.indexOf("cboKhoaDT") >= 0) {
        ClearAllItemsRelatedRCB_MonHoc();
    }
}


function ClearAllItemsRelatedRCB_GiangVien() {
    if (RCBS_GiangVien != null) {
        RCBS_GiangVien.set_text("");
        RCBS_GiangVien.clearItems();
    }
}

function ClearAllItemsRelatedRCB_LopHoc() {

    if (RCBS_LopHoc != null) {
        RCBS_LopHoc.set_text("");
        RCBS_LopHoc.clearItems();

        try {// form: diem danh
            document.getElementById('_ctl0_txtFromDateValid').value = "";
            document.getElementById('_ctl0_txtToDateValid').value = "";
        }
        catch (e) { }
    }
}
function ClearAllItemsRelatedRCB_MonHoc() {

    if (RCBS_MonHoc != null) {
        RCBS_MonHoc.set_text("");
        RCBS_MonHoc.clearItems();
    }
}

function ClearAllItemsRelatedRCB_ToNhom() {
    if (RCBS_ToNhom != null) {
        RCBS_ToNhom.set_text("");
        RCBS_ToNhom.clearItems();
    }
}
//Dùng cho combo cơ cấu trong màn hình QTLV- Thêm mới NV
function ClearAllItemsRelatedRCB_ToNhomAll() {

    if (RCBS_ToNhomAll != null) {
        RCBS_ToNhomAll.set_text("");
        RCBS_ToNhomAll.clearItems();
    }
}

//quanbm2 : su dung chung lun di
function ClearAllItemsRelatedRCB_Obj(Obj) {
    if (Obj != null) {
        Obj.set_text("");
        Obj.clearItems();
    }
}

function ClearAllItemsRelatedRCB_PhongBan() {
    if (RCBS_PhongBan != null) {
        RCBS_PhongBan.set_text("");
        RCBS_PhongBan.clearItems();
    }
}
//Dùng cho combo cơ cấu trong màn hình QTLV- Thêm mới NV
function ClearAllItemsRelatedRCB_PhongBanAll() {
    if (RCBS_PhongBanAll != null) {
        RCBS_PhongBanAll.set_text("");
        RCBS_PhongBanAll.clearItems();
    }
}

function ClearAllItemsRelatedRCB_Level2_() {
    if (RCBS_Level2_ != null) {
        RCBS_Level2_.set_text("");
        RCBS_Level2_.clearItems();
    }
}

function ClearAllItemsRelatedRCB_Level3_() {
    if (RCBS_Level3_ != null) {
        RCBS_Level3_.set_text("");
        RCBS_Level3_.clearItems();
    }
}

function ClearAllItemsRelatedRCB_DonVi() {

    if (RCBS_DonVi != null) {
        RCBS_DonVi.set_text("");
        RCBS_DonVi.clearItems();
    }
}
//Dùng cho combo cơ cấu trong màn hình QTLV- Thêm mới NV
function ClearAllItemsRelatedRCB_DonViAll() {
    if (RCBS_DonViAll != null) {
        RCBS_DonViAll.set_text("");
        RCBS_DonViAll.clearItems();
    }
}
function ClearAllItemsRelatedRCB_Level1_() {
    if (RCBS_Level1_ != null) {
        RCBS_Level1_.set_text("");
        RCBS_Level1_.clearItems();
    }
}
//Dùng cho combo cơ cấu trong màn hình QTLV- Thêm mới NV
function ClearAllItemsRelatedRCB_CongTyAll(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("CompanyAllID") >= 0) {
        ClearAllItemsRelatedRCB_DonViAll();
        ClearAllItemsRelatedRCB_PhongBanAll();
        ClearAllItemsRelatedRCB_ToNhomAll();
        ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level9);

        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel1);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel2);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel3);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel4);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
    }
    else {
        // Nếu combo được thao tác là từ RadComboBox Level1 thì sẽ xóa hết các items của các RadComboBox Level2, Level3
        if (comboID.indexOf("Level1AllID") >= 0) {
            ClearAllItemsRelatedRCB_PhongBanAll();
            ClearAllItemsRelatedRCB_ToNhomAll();
            ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
            ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
            ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
            ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
            ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
            ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
        }
        else {
            if (comboID.indexOf("Level2AllID") >= 0) {
                ClearAllItemsRelatedRCB_ToNhomAll();
                ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level3AllID") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level4ID") >= 0 && comboID.indexOf("HLevel4ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level5ID") >= 0 && comboID.indexOf("HLevel5ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level6ID") >= 0 && comboID.indexOf("HLevel6ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level7ID") >= 0 && comboID.indexOf("HLevel7ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level8ID") >= 0 && comboID.indexOf("HLevel8ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
        }
    }
}

function ClearAllItemsRelatedRCB_Org_(comboID)// hàm clear tong quat
{

    if (comboID.indexOf("CompanyID_") >= 0) {
        ClearAllItemsRelatedRCB_Level1_();
        ClearAllItemsRelatedRCB_Level2_();
        ClearAllItemsRelatedRCB_Level3_();
    }
    else {
        // Nếu combo được thao tác là từ RadComboBox Level1 thì sẽ xóa hết các items của các RadComboBox Level2, Level3
        if (comboID.indexOf("Level1ID_") >= 0) {
            ClearAllItemsRelatedRCB_Level2_();
            ClearAllItemsRelatedRCB_Level3_();
        }
        else {
            if (comboID.indexOf("Level2ID_") >= 0) {
                ClearAllItemsRelatedRCB_Level3_();
            }
        }
    }
}

function ClearAllItemsRelatedRCB_CongTy(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("CompanyID") >= 0 && comboID.indexOf("CompanyID_") < 0) {
        ClearAllItemsRelatedRCB_DonVi();
        ClearAllItemsRelatedRCB_PhongBan();
        ClearAllItemsRelatedRCB_ToNhom();
        ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
        ClearAllItemsRelatedRCB_Obj(RCBS_Level9);

        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel1);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel2);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel3);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel4);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
        ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
    }
    else {
        // Nếu combo được thao tác là từ RadComboBox Level1 thì sẽ xóa hết các items của các RadComboBox Level2, Level3
        if (comboID.indexOf("Level1ID") >= 0 && comboID.indexOf("Level1ID_") < 0) {
            //clear HLevel
            if (comboID.indexOf("LSHLevel1ID") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_HLevel2);
                ClearAllItemsRelatedRCB_Obj(RCBS_HLevel3);
                ClearAllItemsRelatedRCB_Obj(RCBS_HLevel4);
                ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
                ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
            }
            else {
                ClearAllItemsRelatedRCB_PhongBan();
                ClearAllItemsRelatedRCB_ToNhom();
                ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
        }
        else {
            if (comboID.indexOf("Level2ID") >= 0 && comboID.indexOf("Level2ID_") < 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel2ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel3);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_ToNhom();
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
                }
            }
            else if (comboID.indexOf("Level3ID") >= 0 && comboID.indexOf("Level3ID_") < 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel3ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
                }
            }
            else if (comboID.indexOf("Level4ID") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel4ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
                }
            }
            else if (comboID.indexOf("Level5ID") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel5ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
                }
            }
            else if (comboID.indexOf("Level6ID") >= 0 && comboID.indexOf("LSHLevel6ID") < 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level7ID") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
            else if (comboID.indexOf("Level8ID") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_Level9);
            }
        }
    }
}

function ClearAllItemsRelatedRCB_LoaiNguonBaoBH(comboID) {
    if (comboID.indexOf("cboBoMauBH") >= 0) {
        RCBS_LoaiNguonBaoBH.set_text("");
        RCBS_LoaiNguonBaoBH.clearItems();

        RCBS_NguonBaoBH.set_text("");
        RCBS_NguonBaoBH.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NguonBaoBH(comboID) {
    if (comboID.indexOf("cboLoaiNguonBaoBH") >= 0) {
        RCBS_NguonBaoBH.set_text("");
        RCBS_NguonBaoBH.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NguyenNhanTNLD(comboID) {
    if (comboID.indexOf("NhomNguyenNhanTNLD") >= 0) {
        RCBS_NguyenNhanTNLD.set_text("");
        RCBS_NguyenNhanTNLD.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NhomYeuToChanThuong(comboID) {
    if (comboID.indexOf("NhomYeuToChanThuong") >= 0) {
        RCBS_YeuToChanThuong.set_text("");
        RCBS_YeuToChanThuong.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NhomBenhNgheNghiep(comboID) {
    if (comboID.indexOf("NhomBenhNgheNghiep") >= 0) {
        RCBS_BenhNgheNghiep.set_text("");
        RCBS_BenhNgheNghiep.clearItems();
    }
}

function ClearAllItemsRelatedRCB_PhanHe_DyNTmp(comboID) {
    if (comboID.indexOf("PhanHe_DyNTmp") >= 0) {
        RCBS_TenBaoCao_DyNTmp.set_text("");
        RCBS_TenBaoCao_DyNTmp.clearItems();

        RCBS_LoaiThongTin_DyNTmp.set_text("");
        RCBS_LoaiThongTin_DyNTmp.clearItems();
    }
}

function ClearAllItemsRelatedRCB_TenBaoCao_DyNTmp(comboID) {
    if (comboID.indexOf("TenBaoCao_DyNTmp") >= 0) {
        RCBS_LoaiThongTin_DyNTmp.set_text("");
        RCBS_LoaiThongTin_DyNTmp.clearItems();
    }
}

function ClearAllItemsRelatedRCB_SIGroupType(comboID) {
    if (comboID.indexOf("SIGroupType") >= 0 && comboID.indexOf("SIGroupType_Cap2") <= 0) {
        RCBS_SIGroupType_Cap2.set_text("");
        RCBS_SIGroupType_Cap2.clearItems();
    }
}

//Dùng cho combo loại nguồn tuyển dụng - nguồn tuyển dụng - form Lý lịch ứng viên
function ClearAllItemsRelatedRCB_LoaiNguonTuyenDung(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("cboLoaiNguonTuyenDung") >= 0) {
        ClearAllItemsRelatedRCB_NguonTuyenDung();
    }
}
//Demand All

function ClearAllItemsRelatedRCB_DemandAll(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("cboDemandIDAll") >= 0) {
        ClearAllItemsRelatedRCB_Project();
    }
}

function ClearAllItemsRelatedRCB_ProjectAll(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("cboProjectID") >= 0) {
        ClearAllItemsRelatedRCB_ProjectTournament();
    }
}

function ClearAllItemsRelatedRCB_TournamentAll(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("cboProjectTournamentID") >= 0) {
        try { ClearAllItemsRelatedRCB_TournamentSubject(); } catch (err) { }
        try { ClearAllItemsRelatedRCB_TournamentIntContent(); } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_ProjectTournamentAll(comboID)// hàm clear tong quat
{
    if (comboID.indexOf("cboProjectTournamentID") >= 0) {
        ClearAllItemsRelatedRCB_ProjectTournament();
    }
}

//Dùng cho combo loại nguồn tuyển dụng - nguồn tuyển dụng - form Lý lịch ứng viên
function ClearAllItemsRelatedRCB_NguonTuyenDung() {

    if (RCBS_NguonTuyenDung != null) {
        RCBS_NguonTuyenDung.set_text("");
        RCBS_NguonTuyenDung.clearItems();
    }
}
//Project

function ClearAllItemsRelatedRCB_Project() {

    if (RCBS_Project != null) {
        RCBS_Project.set_text("");
        RCBS_Project.clearItems();
        try { ClearAllItemsRelatedRCB_ProjectTournament(); } catch (err) { }
        try { ClearAllItemsRelatedRCB_TournamentSubject(); } catch (err) { }
        try { ClearAllItemsRelatedRCB_TournamentIntContent(); } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_ProjectTournament() {

    if (RCBS_ProjectTournament != null) {
        RCBS_ProjectTournament.set_text("");
        RCBS_ProjectTournament.clearItems();
        try { ClearAllItemsRelatedRCB_TournamentSubject(); } catch (err) { }
        try { ClearAllItemsRelatedRCB_TournamentIntContent(); } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_TournamentSubject() {

    if (RCBS_ProjectTournamentSubject != null) {
        RCBS_ProjectTournamentSubject.set_text("");
        RCBS_ProjectTournamentSubject.clearItems();
    }
}

function ClearAllItemsRelatedRCB_TournamentIntContent() {

    if (RCBS_ProjectTournamentIntContent != null) {
        RCBS_ProjectTournamentIntContent.set_text("");
        RCBS_ProjectTournamentIntContent.clearItems();
    }
}
// ### Request ###

function Related_OnClientItemsRequesting_NguoiYeuCau(context, comboID) { // lamtv2

    if (comboID.indexOf("NguoiYeuCau") >= 0) // this
    {
        context["NhomRERecruitTypeID"] = RCBS_RERecruitTypeID.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_BacLuongSTB(context, comboID) {
    if (comboID.indexOf("HeSoLuong") >= 0) // this
    {
        context["NgayHieuLuc"] = document.getElementById('_ctl0_txtNgayHieuLuc').value; // tạo key parent : tự đặt       
    }
}

function Related_OnClientItemsRequesting_Date(context, comboID) { // lamtv2
    if (comboID.indexOf("Date") >= 0) // this
    {
        context["NhomClass"] = RCBS_LopHoc.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_BacLuong(context, comboID) { // lamtv2

    if (comboID.indexOf("BacLuong") >= 0) // this
    {
        context["NhomnNgachLuong"] = RCBS_NgachLuong.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_BacLuongMem(context, comboID) { // TruyenNG

    if (comboID.indexOf("BacLuong") >= 0) // this
    {
        context["NhomnNgachLuongMem"] = RCBS_NgachLuongMem.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_PhanDoan(context, comboID) { // TruyenNG

    if (comboID.indexOf("PhanDoan") >= 0) // this
    {
        context["NhomChiDoan"] = RCBS_ChiDoan.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_NgachLuong(context, comboID) { // lamtv2

    if (comboID.indexOf("NgachLuong") >= 0) // this
    {
        context["NhomThangLuong"] = RCBS_ThangLuong.get_value(); // tạo key parent : tự đặt
    }
}
function Related_OnClientItemsRequesting_NgachLuongMem(context, comboID) { // TruyenNG

    if (comboID.indexOf("NgachLuongMem") >= 0) // this
    {
        context["NhomThangLuongMem"] = RCBS_ThangLuongMem.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_ChiDoan(context, comboID) { // TruyenNG

    if (comboID.indexOf("ChiDoan") >= 0) // this
    {
        context["NhomLienChiDoan"] = RCBS_LienChiDoan.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_dlModule(context, comboID) { // lamtv2

    if (comboID.indexOf("dlModule") >= 0) // this
    {
        context["UserID"] = RCBS_UserID.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_UserID(context, comboID) { // lamtv2

    if (comboID.indexOf("UserID") >= 0) // this
    {
        context["NhomGroupID"] = RCBS_GroupID.get_value(); // tạo key parent : tự đặt
    }
}



function Related_OnClientItemsRequesting_CopyPer(context, comboID) { // lamtv2

    if (comboID.indexOf("CopyPer") >= 0) // this
    {
        context["NhomLoaiNguoiDung"] = RCBS_LoaiNguoiDung.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_LoaiNguoiDung(context, comboID) { // lamtv2

    if (comboID.indexOf("LoaiNguoiDung") >= 0) // this
    {
        context["NhomLoaiNguoiDung"] = RCBS_LoaiNguoiDung.get_value(); // tạo key parent : tự đặt
    }
}

function Related_OnClientItemsRequesting_KhoaDT(context, comboID) {

    if (comboID.indexOf("KhoaDT") >= 0) // cbo child 
    {
        context["NhomChuongTrinh"] = RCBS_ChuongTrinh.get_value(); // tạo key : tự đặt
    }
}

function Related_OnClientItemsRequesting_ChuongTrinh(context, comboID) {

    //    if(comboID.indexOf("ChuongTrinh") >= 0) // cbo child 
    //    {
    //        context["NhomChuongTrinh"] = RCBS_ChuongTrinh.get_value(); // tạo key : tự đặt
    //    }
}

function Related_OnClientItemsRequesting_GiangVien(context, comboID) {
    if (comboID.indexOf("cboClass") >= 0) // cbo child 
    {
        if (RCBS_cboClass != null)
            context["NhomLopHoc"] = RCBS_cboClass.get_value(); // tạo key : tự đặt
    }
}


function Related_OnClientItemsRequesting_LopHoc(context, comboID) {
    if (comboID.indexOf("cboClassCopy") >= 0) {
        if (RCBS_LSTrainingSubjectIDCopy != null)
            context["NhomMonHoc"] = RCBS_LSTrainingSubjectIDCopy.get_value(); // tạo key : tự đặt
    }
    else if (comboID.indexOf("cboClass") >= 0) {
        if (RCBS_MonHoc != null)
            context["NhomMonHoc"] = RCBS_MonHoc.get_value();
        else if (RCBS_LSTrainingSubjectID != null)
            context["NhomMonHoc"] = RCBS_LSTrainingSubjectID.get_value(); // tạo key : tự đặt
    }
}
function Related_OnClientItemsRequesting_MonHoc(context, comboID) {
    if (comboID.indexOf("cboMonHoc") >= 0) {
        context["NhomKhoaDT"] = RCBS_KhoaDT.get_value();
    }
}

function Related_OnClientItemsRequesting_Level4(context, comboID) {

    if (comboID.indexOf("LSLevel4ID") >= 0 || comboID.indexOf("cboLevel4") >= 0) {        
        if (RCBS_Level3 != null) {
            context["LSLevel3ID"] = RCBS_Level3.get_value();
            context["RelatedString"] = "LSLevel3ID='" + RCBS_Level3.get_value() + "'";
        }
        else if (RCBS_Level3All != null) {
            context["LSLevel3ID"] = RCBS_Level3All.get_value();
            context["RelatedString"] = "LSLevel3ID='" + RCBS_Level3All.get_value() + "'";
        }
        else if (RCBS_ToNhom != null) {
            context["LSLevel3ID"] = RCBS_ToNhom.get_value();
            context["RelatedString"] = "LSLevel3ID='" + RCBS_ToNhom.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Level5(context, comboID) {
    if (comboID.indexOf("LSLevel5ID") >= 0 || comboID.indexOf("cboLevel5") >= 0) {
        if (RCBS_Level4 != null) {
            context["LSLevel4ID"] = RCBS_Level4.get_value();
            context["RelatedString"] = "LSLevel4ID='" + RCBS_Level4.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Level6(context, comboID) {
    if (comboID.indexOf("LSLevel6ID") >= 0 || comboID.indexOf("cboLevel6") >= 0) {
        if (RCBS_Level5 != null) {
            context["LSLevel5ID"] = RCBS_Level5.get_value();
            context["RelatedString"] = "LSLevel5ID='" + RCBS_Level5.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Level7(context, comboID) {
    if (comboID.indexOf("LSLevel7ID") >= 0 || comboID.indexOf("cboLevel7") >= 0) {
        if (RCBS_Level6 != null) {
            context["LSLevel6ID"] = RCBS_Level6.get_value();
            context["RelatedString"] = "LSLevel6ID='" + RCBS_Level6.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Level8(context, comboID) {
    if (comboID.indexOf("LSLevel8ID") >= 0 || comboID.indexOf("cboLevel8") >= 0) {
        if (RCBS_Level7 != null) {
            context["LSLevel7ID"] = RCBS_Level7.get_value();
            context["RelatedString"] = "LSLevel7ID='" + RCBS_Level7.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Level9(context, comboID) {
    if (comboID.indexOf("LSLevel9ID") >= 0 || comboID.indexOf("cboLevel9") >= 0) {
        if (RCBS_Level8 != null) {
            context["LSLevel8ID"] = RCBS_Level8.get_value();
            context["RelatedString"] = "LSLevel8ID='" + RCBS_Level8.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_HLevel(context, comboID) {
    if (comboID.indexOf("cboLSHLevel1ID") >= 0) {
        if (RCBS_EmpHeaderSearch_Company != null) {
            context["LSCompanyID"] = RCBS_EmpHeaderSearch_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpHeaderSearch_Company.get_value() + "'";
        }
        else if (RCBS_CongTy != null) {
            context["LSCompanyID"] = RCBS_CongTy.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_CongTy.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }

    if (comboID.indexOf("cboLSHLevel2ID") >= 0) {
        if (RCBS_HLevel1 != null) {
            context["LSHLevel1ID"] = RCBS_HLevel1.get_value();
            context["RelatedString"] = "LSHLevel1ID='" + RCBS_HLevel1.get_value() + "'";
        }
        else if (RCBS_Header_HLevel1 != null) {
            context["LSHLevel1ID"] = RCBS_Header_HLevel1.get_value();
            context["RelatedString"] = "LSHLevel1ID='" + RCBS_Header_HLevel1.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }

    if (comboID.indexOf("cboLSHLevel3ID") >= 0) {
        if (RCBS_HLevel2 != null) {
            context["LSHLevel2ID"] = RCBS_HLevel2.get_value();
            context["RelatedString"] = "LSHLevel2ID='" + RCBS_HLevel2.get_value() + "'";
        }
        else if (RCBS_Header_HLevel2 != null) {
            context["LSHLevel2ID"] = RCBS_Header_HLevel2.get_value();
            context["RelatedString"] = "LSHLevel2ID='" + RCBS_Header_HLevel2.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }

    if (comboID.indexOf("cboLSHLevel4ID") >= 0) {
        if (RCBS_HLevel3 != null) {
            context["LSHLevel3ID"] = RCBS_HLevel3.get_value();
            context["RelatedString"] = "LSHLevel3ID='" + RCBS_HLevel3.get_value() + "'";
        }
        else if (RCBS_Header_HLevel3 != null) {
            context["LSHLevel3ID"] = RCBS_Header_HLevel3.get_value();
            context["RelatedString"] = "LSHLevel3ID='" + RCBS_Header_HLevel3.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }

    if (comboID.indexOf("cboLSHLevel5ID") >= 0) {
        if (RCBS_HLevel4 != null) {
            context["LSHLevel4ID"] = RCBS_HLevel4.get_value();
            context["RelatedString"] = "LSHLevel4ID='" + RCBS_HLevel4.get_value() + "'";
        }
        else if (RCBS_Header_HLevel4 != null) {
            context["LSHLevel4ID"] = RCBS_Header_HLevel4.get_value();
            context["RelatedString"] = "LSHLevel4ID='" + RCBS_Header_HLevel4.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }

    if (comboID.indexOf("cboLSHLevel6ID") >= 0) {
        if (RCBS_HLevel5 != null) {
            context["LSHLevel5ID"] = RCBS_HLevel5.get_value();
            context["RelatedString"] = "LSHLevel5ID='" + RCBS_HLevel5.get_value() + "'";
        }
        else if (RCBS_Header_HLevel5 != null) {
            context["LSHLevel5ID"] = RCBS_Header_HLevel5.get_value();
            context["RelatedString"] = "LSHLevel5ID='" + RCBS_Header_HLevel5.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_ToNhom(context, comboID) {

    if (comboID.indexOf("LSLevel3ID") >= 0 || comboID.indexOf("cboLevel3") >= 0) // cbo child
    {
        if (RCBS_PhongBan != null)
            context["NhomPhongBan"] = RCBS_PhongBan.get_value(); // tạo key : tự đặt
        else
            context["NhomPhongBan"] = RCBS_PhongBanAll.get_value(); // tạo key : tự đặt
    }
}

function Related_OnClientItemsRequesting_PhongBan(context, comboID) {

    if (comboID.indexOf("LSLevel2ID") >= 0 || comboID.indexOf("cboLevel2") >= 0) // this
    {
        if (RCBS_DonVi != null)
            context["NhomDonVi"] = RCBS_DonVi.get_value(); // tạo key : tự đặt
        else
            context["NhomDonVi"] = RCBS_DonViAll.get_value(); // tạo key : tự đặt
    }
}
function Related_OnClientItemsRequesting_DonVi(context, comboID) {
    if (comboID.indexOf("LSLevel1ID") >= 0 || comboID.indexOf("cboLevel1") >= 0) // this
    {
        if (RCBS_CongTy != null)
            context["NhomLSCompanyID"] = RCBS_CongTy.get_value();  // tạo key parent: tự đặt
        else
            context["NhomLSCompanyID"] = RCBS_CongTyAll.get_value();  // tạo key parent: tự đặt
    }
}

function Related_OnClientItemsRequesting_CongTy(context, comboID) {

    if (comboID.indexOf("LSCompanyID") >= 0) //  this
    {
        context["NhomLSCompanyID"] = RCBS_CongTy.get_value(); // tạo key : tự đặt
    }
}

function Related_OnClientItemsRequesting_BoMauBH(context, comboID) {

    if (comboID.indexOf("MaBoMauBH") >= 0) //  this
    {
        context["NhomMaBoMauBH"] = RCBS_BoMauBH.get_value(); // tạo key : tự đặt
    }
}

function Related_OnClientItemsRequesting_NguonTuyenDung(context, comboID) {
    if (comboID.indexOf("cboNguonTuyenDung") >= 0) // this
    {
        if (comboID.indexOf("cboNguonTuyenDung") >= 0) {
            context["LoaiNguonTuyenDung"] = RCBS_LoaiNguonTuyenDung.get_value();
            context["RelatedString"] = "LSRecruitSourceTypeID='" + RCBS_LoaiNguonTuyenDung.get_value() + "'";
            GetContextByRCB(comboID, context);
        }
    }
}

function Related_OnClientItemsRequesting_Project(context, comboID) {
    if (comboID.indexOf("cboProjectID") >= 0) {
        context["Demand"] = RCBS_DemandAll.get_value();
        context["RelatedString"] = "DemandID='" + RCBS_DemandAll.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_ProjectTournament(context, comboID) {
    if (comboID.indexOf("cboProjectTournamentID") >= 0) // this
    {
        context["Project"] = RCBS_Project.get_value();
        context["RelatedString"] = "ProjectID='" + RCBS_Project.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_TournamentSubject(context, comboID) {
    if (comboID.indexOf("cboTournamentSubjectID") >= 0) {
        context["ProjectTournamentID"] = RCBS_ProjectTournament.get_value();
        context["RelatedString"] = "ProjectTournamentID='" + RCBS_ProjectTournament.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_TournamentIntContent(context, comboID) {
    if (comboID.indexOf("cboTournamentIntContentID") >= 0) {
        context["ProjectTournamentID"] = RCBS_ProjectTournament.get_value();
        context["RelatedString"] = "ProjectTournamentID='" + RCBS_ProjectTournament.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

// Xóa hết các items của các Related RadComboBox Cơ cấu

function ClearAllItemsRelatedRCB_Org(comboID) {
    // Nếu combo được thao tác là từ RadComboBox Company thì sẽ xóa hết các items của các RadComboBox Level1, Level2, Level3
    if (comboID.indexOf("LSOfficeTypeID") >= 0) {
        RCBS_Company.set_text("");
        RCBS_Company.clearItems();

        RCBS_Level1.set_text("");
        RCBS_Level1.clearItems();

        RCBS_Level2.set_text("");
        RCBS_Level2.clearItems();

        RCBS_Level3.set_text("");
        RCBS_Level3.clearItems();
    }
    else if (comboID.indexOf("Company") >= 0 && comboID.indexOf("CompanyID_") < 0) {
        if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
            RCBS_EmpHeaderSearch1_Level1.set_text("");
            RCBS_EmpHeaderSearch1_Level1.clearItems();

            RCBS_EmpHeaderSearch1_Level2.set_text("");
            RCBS_EmpHeaderSearch1_Level2.clearItems();

            RCBS_EmpHeaderSearch1_Level3.set_text("");
            RCBS_EmpHeaderSearch1_Level3.clearItems();

            RCBS_EmpHeaderSearch1_Level4.set_text("");
            RCBS_EmpHeaderSearch1_Level4.clearItems();
            RCBS_EmpHeaderSearch1_Level5.set_text("");
            RCBS_EmpHeaderSearch1_Level5.clearItems();
            RCBS_EmpHeaderSearch1_Level6.set_text("");
            RCBS_EmpHeaderSearch1_Level6.clearItems();
            RCBS_EmpHeaderSearch1_Level7.set_text("");
            RCBS_EmpHeaderSearch1_Level7.clearItems();
            RCBS_EmpHeaderSearch1_Level8.set_text("");
            RCBS_EmpHeaderSearch1_Level8.clearItems();
            RCBS_EmpHeaderSearch1_Level9.set_text("");
            RCBS_EmpHeaderSearch1_Level9.clearItems();
        }
        else if (comboID.indexOf("TrPlanHeader1") >= 0) {
            RCBS_TrPlanHeader1_Level1.set_text("");
            RCBS_TrPlanHeader1_Level1.clearItems();

            RCBS_TrPlanHeader1_Level2.set_text("");
            RCBS_TrPlanHeader1_Level2.clearItems();

            RCBS_TrPlanHeader1_Level3.set_text("");
            RCBS_TrPlanHeader1_Level3.clearItems();

            RCBS_TrPlanHeader1_Level4.set_text("");
            RCBS_TrPlanHeader1_Level4.clearItems();
            RCBS_TrPlanHeader1_Level5.set_text("");
            RCBS_TrPlanHeader1_Level5.clearItems();
            RCBS_TrPlanHeader1_Level6.set_text("");
            RCBS_TrPlanHeader1_Level6.clearItems();
            RCBS_TrPlanHeader1_Level7.set_text("");
            RCBS_TrPlanHeader1_Level7.clearItems();
            RCBS_TrPlanHeader1_Level8.set_text("");
            RCBS_TrPlanHeader1_Level8.clearItems();
            RCBS_TrPlanHeader1_Level9.set_text("");
            RCBS_TrPlanHeader1_Level9.clearItems();
        }
        else if (comboID.indexOf("OrgSelectSimple1") >= 0) {

            RCBS_OrgSelectSimple1_Level1.set_text("");
            RCBS_OrgSelectSimple1_Level1.clearItems();

            RCBS_OrgSelectSimple1_Level2.set_text("");
            RCBS_OrgSelectSimple1_Level2.clearItems();

            RCBS_OrgSelectSimple1_Level3.set_text("");
            RCBS_OrgSelectSimple1_Level3.clearItems();

            RCBS_OrgSelectSimple1_Level4.set_text("");
            RCBS_OrgSelectSimple1_Level4.clearItems();
            RCBS_OrgSelectSimple1_Level5.set_text("");
            RCBS_OrgSelectSimple1_Level5.clearItems();
            RCBS_OrgSelectSimple1_Level6.set_text("");
            RCBS_OrgSelectSimple1_Level6.clearItems();
            RCBS_OrgSelectSimple1_Level7.set_text("");
            RCBS_OrgSelectSimple1_Level7.clearItems();
            RCBS_OrgSelectSimple1_Level8.set_text("");
            RCBS_OrgSelectSimple1_Level8.clearItems();
            RCBS_OrgSelectSimple1_Level9.set_text("");
            RCBS_OrgSelectSimple1_Level9.clearItems();
        }

        else if (comboID.indexOf("TrCourseHeader1") >= 0) {
            RCBS_TrCourseHeader1_Level1.set_text("");
            RCBS_TrCourseHeader1_Level1.clearItems();

            RCBS_TrCourseHeader1_Level2.set_text("");
            RCBS_TrCourseHeader1_Level2.clearItems();

            RCBS_TrCourseHeader1_Level3.set_text("");
            RCBS_TrCourseHeader1_Level3.clearItems();
            RCBS_TrCourseHeader1_Level4.set_text("");
            RCBS_TrCourseHeader1_Level4.clearItems();
            RCBS_TrCourseHeader1_Level5.set_text("");
            RCBS_TrCourseHeader1_Level5.clearItems();
            RCBS_TrCourseHeader1_Level6.set_text("");
            RCBS_TrCourseHeader1_Level6.clearItems();
            RCBS_TrCourseHeader1_Level7.set_text("");
            RCBS_TrCourseHeader1_Level7.clearItems();
            RCBS_TrCourseHeader1_Level8.set_text("");
            RCBS_TrCourseHeader1_Level8.clearItems();
            RCBS_TrCourseHeader1_Level9.set_text("");
            RCBS_TrCourseHeader1_Level9.clearItems();
        }
        else if (comboID.indexOf("OrgSelectSimple_H1") >= 0) {
            RCBS_OrgSelectSimple_H1_cboLevel1.set_text("");
            RCBS_OrgSelectSimple_H1_cboLevel1.clearItems();

            RCBS_OrgSelectSimple_H1_cboLevel2.set_text("");
            RCBS_OrgSelectSimple_H1_cboLevel2.clearItems();

            RCBS_OrgSelectSimple_H1_cboLevel3.set_text("");
            RCBS_OrgSelectSimple_H1_cboLevel3.clearItems();
        }
        else if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
            RCBS_EmpHeaderSearch_Level1.set_text("");
            RCBS_EmpHeaderSearch_Level1.clearItems();

            RCBS_EmpHeaderSearch_Level2.set_text("");
            RCBS_EmpHeaderSearch_Level2.clearItems();

            RCBS_EmpHeaderSearch_Level3.set_text("");
            RCBS_EmpHeaderSearch_Level3.clearItems();

            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level4);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level5);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);

            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel1);
            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel2);
            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel3);
            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel4);
            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel5);
            ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
        }
        else if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
            RCBS_EmpHeaderSearchSI_Level1.set_text("");
            RCBS_EmpHeaderSearchSI_Level1.clearItems();

            RCBS_EmpHeaderSearchSI_Level2.set_text("");
            RCBS_EmpHeaderSearchSI_Level2.clearItems();

            RCBS_EmpHeaderSearchSI_Level3.set_text("");
            RCBS_EmpHeaderSearchSI_Level3.clearItems();
        }
        else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
            RCBS_EmpHeaderSearchReport_Level1.set_text("");
            RCBS_EmpHeaderSearchReport_Level1.clearItems();

            RCBS_EmpHeaderSearchReport_Level2.set_text("");
            RCBS_EmpHeaderSearchReport_Level2.clearItems();

            RCBS_EmpHeaderSearchReport_Level3.set_text("");
            RCBS_EmpHeaderSearchReport_Level3.clearItems();
        }
        else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
            RCBS_EmpSearchSimple_Level1.set_text("");
            RCBS_EmpSearchSimple_Level1.clearItems();

            RCBS_EmpSearchSimple_Level2.set_text("");
            RCBS_EmpSearchSimple_Level2.clearItems();

            RCBS_EmpSearchSimple_Level3.set_text("");
            RCBS_EmpSearchSimple_Level3.clearItems();
        }
        else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
            RCBS_EmpSearchSimple3_Level1.set_text("");
            RCBS_EmpSearchSimple3_Level1.clearItems();

            RCBS_EmpSearchSimple3_Level2.set_text("");
            RCBS_EmpSearchSimple3_Level2.clearItems();

            RCBS_EmpSearchSimple3_Level3.set_text("");
            RCBS_EmpSearchSimple3_Level3.clearItems();

            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level4);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level5);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level6);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level7);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level8);
            ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple3_Level9);
        }
        else {
            RCBS_Level1.set_text("");
            RCBS_Level1.clearItems();

            RCBS_Level2.set_text("");
            RCBS_Level2.clearItems();

            RCBS_Level3.set_text("");
            RCBS_Level3.clearItems();
        }
    }
    else {
        // Nếu combo được thao tác là từ RadComboBox Level1 thì sẽ xóa hết các items của các RadComboBox Level2, Level3
        if (comboID.indexOf("Level1") >= 0 && comboID.indexOf("Level1ID_") < 0) {
            if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
                RCBS_EmpHeaderSearch1_Level2.set_text("");
                RCBS_EmpHeaderSearch1_Level2.clearItems();

                RCBS_EmpHeaderSearch1_Level3.set_text("");
                RCBS_EmpHeaderSearch1_Level3.clearItems();
                RCBS_EmpHeaderSearch1_Level4.set_text("");
                RCBS_EmpHeaderSearch1_Level4.clearItems();
                RCBS_EmpHeaderSearch1_Level5.set_text("");
                RCBS_EmpHeaderSearch1_Level5.clearItems();
                RCBS_EmpHeaderSearch1_Level6.set_text("");
                RCBS_EmpHeaderSearch1_Level6.clearItems();
                RCBS_EmpHeaderSearch1_Level7.set_text("");
                RCBS_EmpHeaderSearch1_Level7.clearItems();
                RCBS_EmpHeaderSearch1_Level8.set_text("");
                RCBS_EmpHeaderSearch1_Level8.clearItems();
                RCBS_EmpHeaderSearch1_Level9.set_text("");
                RCBS_EmpHeaderSearch1_Level9.clearItems();
            }
            else
                if (comboID.indexOf("TrPlanHeader1") >= 0) {
                RCBS_TrPlanHeader1_Level2.set_text("");
                RCBS_TrPlanHeader1_Level2.clearItems();

                RCBS_TrPlanHeader1_Level3.set_text("");
                RCBS_TrPlanHeader1_Level3.clearItems();

                RCBS_TrPlanHeader1_Level4.set_text("");
                RCBS_TrPlanHeader1_Level4.clearItems();
                RCBS_TrPlanHeader1_Level5.set_text("");
                RCBS_TrPlanHeader1_Level5.clearItems();
                RCBS_TrPlanHeader1_Level6.set_text("");
                RCBS_TrPlanHeader1_Level6.clearItems();
                RCBS_TrPlanHeader1_Level7.set_text("");
                RCBS_TrPlanHeader1_Level7.clearItems();
                RCBS_TrPlanHeader1_Level8.set_text("");
                RCBS_TrPlanHeader1_Level8.clearItems();
                RCBS_TrPlanHeader1_Level9.set_text("");
                RCBS_TrPlanHeader1_Level9.clearItems();
            }
            else
                if (comboID.indexOf("OrgSelectSimple1") >= 0) {
                RCBS_OrgSelectSimple1_Level2.set_text("");
                RCBS_OrgSelectSimple1_Level2.clearItems();

                RCBS_OrgSelectSimple1_Level3.set_text("");
                RCBS_OrgSelectSimple1_Level3.clearItems();

                RCBS_OrgSelectSimple1_Level4.set_text("");
                RCBS_OrgSelectSimple1_Level4.clearItems();
                RCBS_OrgSelectSimple1_Level5.set_text("");
                RCBS_OrgSelectSimple1_Level5.clearItems();
                RCBS_OrgSelectSimple1_Level6.set_text("");
                RCBS_OrgSelectSimple1_Level6.clearItems();
                RCBS_OrgSelectSimple1_Level7.set_text("");
                RCBS_OrgSelectSimple1_Level7.clearItems();
                RCBS_OrgSelectSimple1_Level8.set_text("");
                RCBS_OrgSelectSimple1_Level8.clearItems();
                RCBS_OrgSelectSimple1_Level9.set_text("");
                RCBS_OrgSelectSimple1_Level9.clearItems();
            }

            else
                if (comboID.indexOf("OrgSelectSimple_H1") >= 0) {
                RCBS_OrgSelectSimple_H1_cboLevel2.set_text("");
                RCBS_OrgSelectSimple_H1_cboLevel2.clearItems();

                RCBS_OrgSelectSimple_H1_cboLevel3.set_text("");
                RCBS_OrgSelectSimple_H1_cboLevel3.clearItems();
            }
            else
                if (comboID.indexOf("TrCourseHeader1") >= 0) {
                RCBS_TrCourseHeader1_Level2.set_text("");
                RCBS_TrCourseHeader1_Level2.clearItems();

                RCBS_TrCourseHeader1_Level3.set_text("");
                RCBS_TrCourseHeader1_Level3.clearItems();
                RCBS_TrCourseHeader1_Level4.set_text("");
                RCBS_TrCourseHeader1_Level4.clearItems();
                RCBS_TrCourseHeader1_Level5.set_text("");
                RCBS_TrCourseHeader1_Level5.clearItems();
                RCBS_TrCourseHeader1_Level6.set_text("");
                RCBS_TrCourseHeader1_Level6.clearItems();
                RCBS_TrCourseHeader1_Level7.set_text("");
                RCBS_TrCourseHeader1_Level7.clearItems();
                RCBS_TrCourseHeader1_Level8.set_text("");
                RCBS_TrCourseHeader1_Level8.clearItems();
                RCBS_TrCourseHeader1_Level9.set_text("");
                RCBS_TrCourseHeader1_Level9.clearItems();
            }
            else
                if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel1ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel2);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel3);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level2);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level3);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
                }
            }
            else
                if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearchSI_Level2);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearchSI_Level3);
                }
            else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
                RCBS_EmpHeaderSearchReport_Level2.set_text("");
                RCBS_EmpHeaderSearchReport_Level2.clearItems();

                RCBS_EmpHeaderSearchReport_Level3.set_text("");
                RCBS_EmpHeaderSearchReport_Level3.clearItems();
            }
            else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
                RCBS_EmpSearchSimple_Level2.set_text("");
                RCBS_EmpSearchSimple_Level2.clearItems();

                RCBS_EmpSearchSimple_Level3.set_text("");
                RCBS_EmpSearchSimple_Level3.clearItems();
            }
            else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
                RCBS_EmpSearchSimple3_Level2.set_text("");
                RCBS_EmpSearchSimple3_Level2.clearItems();

                RCBS_EmpSearchSimple3_Level3.set_text("");
                RCBS_EmpSearchSimple3_Level3.clearItems();

                RCBS_EmpSearchSimple3_Level4.set_text("");
                RCBS_EmpSearchSimple3_Level4.clearItems();

                RCBS_EmpSearchSimple3_Level5.set_text("");
                RCBS_EmpSearchSimple3_Level5.clearItems();

                RCBS_EmpSearchSimple3_Level6.set_text("");
                RCBS_EmpSearchSimple3_Level6.clearItems();

                RCBS_EmpSearchSimple3_Level7.set_text("");
                RCBS_EmpSearchSimple3_Level7.clearItems();

                RCBS_EmpSearchSimple3_Level8.set_text("");
                RCBS_EmpSearchSimple3_Level8.clearItems();

                RCBS_EmpSearchSimple3_Level9.set_text("");
                RCBS_EmpSearchSimple3_Level9.clearItems();
            }
            else {
                if (comboID.indexOf("HLevel1") < 0) {
                    RCBS_Level2.set_text("");
                    RCBS_Level2.clearItems();

                    RCBS_Level3.set_text("");
                    RCBS_Level3.clearItems();
                }
            }
        }
        else {
            // Nếu combo được thao tác là từ RadComboBox Level2 thì sẽ xóa hết các items của các RadComboBox Level3
            if (comboID.indexOf("Level2") >= 0 && comboID.indexOf("Level2ID_") < 0) {
                if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
                    RCBS_EmpHeaderSearch1_Level3.set_text("");
                    RCBS_EmpHeaderSearch1_Level3.clearItems();
                    RCBS_EmpHeaderSearch1_Level4.set_text("");
                    RCBS_EmpHeaderSearch1_Level4.clearItems();
                    RCBS_EmpHeaderSearch1_Level5.set_text("");
                    RCBS_EmpHeaderSearch1_Level5.clearItems();
                    RCBS_EmpHeaderSearch1_Level6.set_text("");
                    RCBS_EmpHeaderSearch1_Level6.clearItems();
                    RCBS_EmpHeaderSearch1_Level7.set_text("");
                    RCBS_EmpHeaderSearch1_Level7.clearItems();
                    RCBS_EmpHeaderSearch1_Level8.set_text("");
                    RCBS_EmpHeaderSearch1_Level8.clearItems();
                    RCBS_EmpHeaderSearch1_Level9.set_text("");
                    RCBS_EmpHeaderSearch1_Level9.clearItems();
                }
                else
                    if (comboID.indexOf("TrCourseHeader1") >= 0) {
                    RCBS_TrCourseHeader1_Level3.set_text("");
                    RCBS_TrCourseHeader1_Level3.clearItems();

                    RCBS_TrCourseHeader1_Level4.set_text("");
                    RCBS_TrCourseHeader11_Level4.clearItems();
                    RCBS_TrCourseHeader1_Level5.set_text("");
                    RCBS_TrCourseHeader1_Level5.clearItems();
                    RCBS_TrCourseHeader1_Level6.set_text("");
                    RCBS_TrCourseHeader1_Level6.clearItems();
                    RCBS_TrCourseHeader1_Level7.set_text("");
                    RCBS_TrCourseHeader1_Level7.clearItems();
                    RCBS_TrCourseHeader1_Level8.set_text("");
                    RCBS_TrCourseHeader1_Level8.clearItems();
                    RCBS_TrCourseHeader1_Level9.set_text("");
                    RCBS_TrCourseHeader1_Level9.clearItems();
                }
                else
                    if (comboID.indexOf("TrPlanHeader1") >= 0) {
                    RCBS_TrPlanHeader1_Level3.set_text("");
                    RCBS_TrPlanHeader1_Level3.clearItems();

                    RCBS_TrPlanHeader1_Level4.set_text("");
                    RCBS_TrPlanHeader1_Level4.clearItems();
                    RCBS_TrPlanHeader1_Level5.set_text("");
                    RCBS_TrPlanHeader1_Level5.clearItems();
                    RCBS_TrPlanHeader1_Level6.set_text("");
                    RCBS_TrPlanHeader1_Level6.clearItems();
                    RCBS_TrPlanHeader1_Level7.set_text("");
                    RCBS_TrPlanHeader1_Level7.clearItems();
                    RCBS_TrPlanHeader1_Level8.set_text("");
                    RCBS_TrPlanHeader1_Level8.clearItems();
                    RCBS_TrPlanHeader1_Level9.set_text("");
                    RCBS_TrPlanHeader1_Level9.clearItems();
                }
                else
                    if (comboID.indexOf("OrgSelectSimple1") >= 0) {
                    RCBS_OrgSelectSimple1_Level3.set_text("");
                    RCBS_OrgSelectSimple1_Level3.clearItems();

                    RCBS_OrgSelectSimple1_Level4.set_text("");
                    RCBS_OrgSelectSimple1_Level4.clearItems();
                    RCBS_OrgSelectSimple1_Level5.set_text("");
                    RCBS_OrgSelectSimple1_Level5.clearItems();
                    RCBS_OrgSelectSimple1_Level6.set_text("");
                    RCBS_OrgSelectSimple1_Level6.clearItems();
                    RCBS_OrgSelectSimple1_Level7.set_text("");
                    RCBS_OrgSelectSimple1_Level7.clearItems();
                    RCBS_OrgSelectSimple1_Level8.set_text("");
                    RCBS_OrgSelectSimple1_Level8.clearItems();
                    RCBS_OrgSelectSimple1_Level9.set_text("");
                    RCBS_OrgSelectSimple1_Level9.clearItems();
                }

                else
                    if (comboID.indexOf("OrgSelectSimple_H1") >= 0) {
                    RCBS_OrgSelectSimple_H1_cboLevel3.set_text("");
                    RCBS_OrgSelectSimple_H1_cboLevel3.clearItems();
                }
                else if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
                    //clear HLevel
                    if (comboID.indexOf("LSHLevel2ID") >= 0) {
                        ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel3);
                        ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel4);
                        ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel5);
                        ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
                    }
                    else {
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level3);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level4);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level5);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
                    }
                }
                else
                    if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
                        ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearchSI_Level3);
                    }
                else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearchReport_Level3);
                }
                else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpSearchSimple_Level3);
                }
                else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
                    RCBS_EmpSearchSimple3_Level3.set_text("");
                    RCBS_EmpSearchSimple3_Level3.clearItems();

                    RCBS_EmpSearchSimple3_Level4.set_text("");
                    RCBS_EmpSearchSimple3_Level4.clearItems();
                    RCBS_EmpSearchSimple3_Level5.set_text("");
                    RCBS_EmpSearchSimple3_Level5.clearItems();
                    RCBS_EmpSearchSimple3_Level6.set_text("");
                    RCBS_EmpSearchSimple3_Level6.clearItems();
                    RCBS_EmpSearchSimple3_Level7.set_text("");
                    RCBS_EmpSearchSimple3_Level7.clearItems();
                    RCBS_EmpSearchSimple3_Level8.set_text("");
                    RCBS_EmpSearchSimple3_Level8.clearItems();
                    RCBS_EmpSearchSimple3_Level9.set_text("");
                    RCBS_EmpSearchSimple3_Level9.clearItems();
                }
                else {
                    if (comboID.indexOf("HLevel2") < 0)
                        ClearAllItemsRelatedRCB_Obj(RCBS_Level3);
                }
            }
            else if (comboID.indexOf("Level3") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level4);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level3") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level4);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_OrgSelectSimple1_Level9);
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level5);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level6);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch1_Level9);
            }
            else if (comboID.indexOf("Level3") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel3ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level4);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
                }
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel4ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level5);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
                }
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                //clear HLevel
                if (comboID.indexOf("LSHLevel5ID") >= 0) {
                    ClearAllItemsRelatedRCB_Obj(RCBS_Header_HLevel6);
                }
                else {
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level6);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                    ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
                }

            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level7);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level8);
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);

            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                ClearAllItemsRelatedRCB_Obj(RCBS_EmpHeaderSearch_Level9);
            }

        }
    }
}

function ClearAllItemsRelatedRCB_CCDC(comboID) {
    if (comboID.indexOf("cboLoaiTaiSan") >= 0) {
        RCBS_NhomTaiSan.set_text("");
        RCBS_NhomTaiSan.clearItems();

        if (RCBS_CCDC != null) {
            RCBS_CCDC.set_text("");
            RCBS_CCDC.clearItems();
        }
        // xóa tiếp CCDC...
    }
    else if (comboID.indexOf("cboNhomCCDC") >= 0) {
        //....xóa thứ CCDC.
        if (RCBS_CCDC != null) {
            RCBS_CCDC.set_text("");
            RCBS_CCDC.clearItems();
        }
    }
}

// Xóa hết các items của các Related RadComboBox Bank (Ngân hàng, Chi nhánh)
function ClearAllItemsRelatedRCB_Bank(comboID) {
    if (comboID.indexOf("cboLSBankID") >= 0) {
        if (comboID.indexOf("_Second") >= 0) {
            RCBS_BankBranch_Second.set_text("");
            RCBS_BankBranch_Second.clearItems();
        }
        else {
            RCBS_BankBranch.set_text("");
            RCBS_BankBranch.clearItems();
        }
    }
}

// Xóa hết các items của các Related RadComboBox Template (Template, Cột dữ liệu LinkServer)
function ClearAllItemsRelatedRCB_TemplateLinkServer(comboID) {
    if (comboID.indexOf("cboLSTemplateLinkServerID") >= 0) {
        RCBS_TypeDataLinkServer.set_text("");
        RCBS_TypeDataLinkServer.clearItems();
    }
}


// Xóa hết các items của các Related RadComboBox Nhóm Chi Phi Hanh Chinh
function ClearAllItemsRelatedRCB_NhomChiPhiHanhChinh(comboID) {
    if (comboID.indexOf("cboLSNhomChiPhiHanhChinhID") >= 0) {
        RCBS_ChiPhiHanhChinh.set_text("");
        RCBS_ChiPhiHanhChinh.clearItems();
    }
}
// Xóa hết các items của các Related RadComboBox Loai San Pham
function ClearAllItemsRelatedRCB_LoaiSanPham(comboID) {
    if (comboID.indexOf("cboLSLoaiSanPhamID") >= 0) {
        RCBS_CongDoanSX.set_text("");
        RCBS_CongDoanSX.clearItems();
    }
}

// Xóa hết các items của các Related RadComboBox Nhóm kỹ năng,Loại kỹ năng
function ClearAllItemsRelatedRCB_SkillGroup(comboID) {
    if (comboID.indexOf("cboLSSkillGroupID") >= 0) {
        RCBS_SkillType.set_text("");
        RCBS_SkillType.clearItems();
        ClearAllItemsRelatedRCB_SkillType("cboLSSkillTypeID")
    }
}

// Xóa hết các items của các Related RadComboBox Nhóm kỹ năng,Loại kỹ năng
function ClearAllItemsRelatedRCB_SkillType(comboID) {
    if (comboID.indexOf("cboLSSkillTypeID") >= 0) {
        RCBS_EmpSkill.set_text("");
        RCBS_EmpSkill.clearItems();
    }
}

// Xóa hết các items của các Related RadComboBox Loai Bang Cap
function ClearAllItemsRelatedRCB_ProfessionalLevelType(comboID) {
    if (comboID.indexOf("cboLSProfessionalLevelTypeID") >= 0) {
        RCBS_TrainingRange.set_text("");
        RCBS_TrainingRange.clearItems();
    }
}
function ClearAllItemsRelatedRCB_BangLuong(comboID) {
    if (comboID.indexOf("cboLSBangLuongID") >= 0) {
        RCBS_ThangLuong.set_text("");
        RCBS_ThangLuong.clearItems();
        ClearAllItemsRelatedRCB_NgachLuong();
    }
    if (comboID.indexOf("ThangLuong") >= 0) {
        ClearAllItemsRelatedRCB_NgachLuong();
    }
}
function ClearAllItemsRelatedRCB_BangLuongMem(comboID) {
    if (comboID.indexOf("cboLSBangLuongMemID") >= 0) {
        RCBS_ThangLuongMem.set_text("");
        RCBS_ThangLuongMem.clearItems();
        ClearAllItemsRelatedRCB_NgachLuongMem();
    }
    if (comboID.indexOf("ThangLuongMem") >= 0) {
        ClearAllItemsRelatedRCB_NgachLuongMem();
    }
}

function ClearAllItemsRelatedRCB_UserType(comboID) {
    if (comboID.indexOf("cboLoaiNguoiDung") >= 0) {
        RCBS_UserGroup.set_text("");
        RCBS_UserGroup.clearItems();
    }
}

function ClearAllItemsRelatedRCB_JobCodeGroup(comboID) {
    if (comboID.indexOf("cboLSJobCodeGroupID") >= 0) {
        RCBS_JobCode.set_text("");
        RCBS_JobCode.clearItems();
        try {
            ClearAllItemsRelatedRCB_JobCode("_ctl0_cboLSJobCodeID");
        } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_ProjectList(comboID) {
    if (comboID.indexOf("cboLSProjectList") >= 0) {
        RCBS_LenhSanXuat.set_text("");
        RCBS_LenhSanXuat.clearItems();
    }
}

function ClearAllItemsRelatedRCB_APPYear(comboID) {
    if (comboID.indexOf("cboYear") >= 0 && comboID.indexOf("cboYear_") < 0) {
        try {
            RCBS_APPPeriod.set_text("");
            RCBS_APPPeriod.clearItems();
        } catch (err) { }
        try {
            ClearAllItemsRelatedRCB_APPPeriod("_ctl0_cboAPPPeriod");
        } catch (err) { }
        try {
            RCBS_OpenAPPPeriod.set_text("");
            RCBS_OpenAPPPeriod.clearItems();
        } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_APPYear_(comboID) {
    if (comboID.indexOf("cboYear_") >= 0) {
        try {
            RCBS_APPPeriod_.set_text("");
            RCBS_APPPeriod_.clearItems();
        } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_APPPeriod(comboID) {
    if (comboID.indexOf("cboAPPPeriod") >= 0) {
        try {
            RCBS_APPSubject.set_text("");
            RCBS_APPSubject.clearItems();
        } catch (err) { }
    }
}

function ClearAllItemsRelatedRCB_JobCode(comboID) {
    if (comboID.indexOf("cboLSJobCodeID") >= 0) {
        RCBS_JobType.set_text("");
        RCBS_JobType.clearItems();
    }
}

function ClearAllItemsRelatedRCB_JobFunction(comboID) {
    if (comboID.indexOf("cboLSChucVuID") >= 0) {
        RCBS_JobTitle.set_text("");
        RCBS_JobTitle.clearItems();
    }
}

function ClearAllItemsRelatedRCB_NhomCongViec(comboID) {
    if (comboID.indexOf("cboLSNhomNoiDungCVID") >= 0) {
        RCBS_LoaiCongViec.set_text("");
        RCBS_LoaiCongViec.clearItems();
    }
}

function ClearAllItemsRelatedRCB_P_LSProvinceID() { // lamtv2
    if (RCBS_P_LSProvinceID != null) {
        RCBS_P_LSProvinceID.set_text("");
        RCBS_P_LSProvinceID.clearItems();
    }
}

function ClearAllItemsRelatedRCB_P_District_() { // lamtv2
    if (RCBS_P_District_ != null) {
        RCBS_P_District_.set_text("");
        RCBS_P_District_.clearItems();
    }
}

function ClearAllItemsRelatedRCB_T_District_() { // lamtv2
    if (RCBS_T_District_ != null) {
        RCBS_T_District_.set_text("");
        RCBS_T_District_.clearItems();
        
        RCBS_T_Ward.set_text("");
        RCBS_T_Ward.clearItems();
        
    }
}

function ClearAllItemsRelatedRCB_T_District(comboID) {
    if (comboID.indexOf("cboT_District") >= 0) {
        try {
            /////////Phuong/Xa//////
            RCBS_T_Ward.set_text("");
            RCBS_T_Ward.clearItems();
            /////////Phuong/Xa//////
        }
        catch (e) {}
    }
}

// Xóa hết các items của các Related RadComboBox 
function ClearAllItemsRelatedRCB_District(comboID) {

    if (comboID.indexOf("cboP_District") >= 0) {

        try {
            /////////Phuong/Xa//////
            RCBS_P_Ward.set_text("");
            RCBS_P_Ward.clearItems();
            /////////Phuong/Xa//////
        }
        catch (e) { }
    }
}


// Xóa hết các items của các Related RadComboBox Province (Tỉnh thành, Quận huyện)
function ClearAllItemsRelatedRCB_Province(comboID) {

    if (comboID.indexOf("cboP_LSProvinceID") >= 0) {

        try {
            RCBS_P_District.set_text("");
            RCBS_P_District.clearItems();
            ///////Phuong/xa////////
            RCBS_P_Ward.set_text("");
            RCBS_P_Ward.clearItems();
            ///////Phuong/xa////////
        }
        catch (e) { }
        ClearAllItemsRelatedRCB_P_District_();
    }
    else
        if (comboID.indexOf("cboT_LSProvinceID") >= 0) {
        try {
            RCBS_T_District.set_text("");
            RCBS_T_District.clearItems();
            ///////Phuong/xa////////
            RCBS_T_Ward.set_text("");
            RCBS_T_Ward.clearItems();
            ///////Phuong/xa////////
        }
        catch (e) { }
        ClearAllItemsRelatedRCB_T_District_();
    }
}

function ClearAllItemsRelatedRCB_ChucDanhDuAn(comboID) {
    if (comboID.indexOf("cboNhomChucDanh") >= 0) {
        RCBS_ChucDanhDuAn.set_text("");
        RCBS_ChucDanhDuAn.clearItems();
    }
}

function ClearAllItemsRelatedRCB_ChucDanhDuAnCopy(comboID) {
    if (comboID.indexOf("cboNhomChucDanhCopy") >= 0) {
        RCBS_ChucDanhDuAnCopy.set_text("");
        RCBS_ChucDanhDuAnCopy.clearItems();
    }
}

function ClearAllItemsRelatedRCB_cboProjectVersionID(comboID) {
    if (comboID.indexOf("cboDuAn") >= 0) {
        RCBS_ProjectVersionID.set_text("");
        RCBS_ProjectVersionID.clearItems();
    }
}

// Hàm dùng để xóa text và các items của related RadComboBox
// Hàm này sẽ được sử dụng khi thực hiện chọn 1 item từ RadComboBox, các related liên quan sẽ được xóa text và items
function ClearAllItemsRelatedRCB(combo, eventArqs) {
    // Khởi tạo các biến cho các related RadComboBox cơ cấu
    InitRCB();

    // Lấy về ID của RadComboBox được thao tác    
    var comboID = combo.get_id();

    // Clear all items related RadComboBox Org
    try // Lamtv2
    {
        ClearAllItemsRelatedRCB_Org(comboID);
    }
    catch (e) { }
    ClearAllItemsRelatedRCB_ChucDanhDuAn(comboID);
    ClearAllItemsRelatedRCB_ChucDanhDuAnCopy(comboID);
    ClearAllItemsRelatedRCB_LSTrainingTopicID(comboID);
    
    ClearAllItemsRelatedRCB_cboProjectVersionID(comboID);
    // Clear all items related RadComboBox Province
    ClearAllItemsRelatedRCB_Province(comboID);
    ///////////////////ClearPhuongXa//////////
    ClearAllItemsRelatedRCB_District(comboID);
    ClearAllItemsRelatedRCB_T_District(comboID);
    // Clear all items related RadComboBox Bank
    ClearAllItemsRelatedRCB_Bank(comboID);
    ClearAllItemsRelatedRCB_TemplateLinkServer(comboID);
    ClearAllItemsRelatedRCB_NhomChiPhiHanhChinh(comboID);
    ClearAllItemsRelatedRCB_LoaiSanPham(comboID);
    ClearAllItemsRelatedRCB_SkillGroup(comboID);
    ClearAllItemsRelatedRCB_SkillType(comboID);
    ClearAllItemsRelatedRCB_ProfessionalLevelType(comboID);
    ClearAllItemsRelatedRCB_BangLuong(comboID);
    ClearAllItemsRelatedRCB_BangLuongMem(comboID);
    ClearAllItemsRelatedRCB_UserType(comboID);
    ClearAllItemsRelatedRCB_CCDC(comboID);

    ClearAllItemsRelatedRCB_JobCodeGroup(comboID);
    ClearAllItemsRelatedRCB_JobCode(comboID);

    ClearAllItemsRelatedRCB_APPYear(comboID);
    ClearAllItemsRelatedRCB_APPYear_(comboID);
    ClearAllItemsRelatedRCB_APPPeriod(comboID);

    ClearAllItemsRelatedRCB_JobFunction(comboID);
    ClearAllItemsRelatedRCB_NhomCongViec(comboID);
    
    ClearAllItemsRelatedRCB_Nam(comboID);
    ClearAllItemsRelatedRCB_NamKH(comboID);
    //    alert(1);
    try // lamtv2
    {
        ClearAllItemsRelatedRCB_CongTy(comboID);
    }
    catch (e) { }
    //    alert(2);
    try // TrangNT: Dùng cho 4 combo cơ cấu trong màn hình QTLV - Thêm mới NV
    {
        ClearAllItemsRelatedRCB_CongTyAll(comboID);
    }
    catch (e) { }
    //    alert(3);
    try {
        ClearAllItemsRelatedRCB_Org_(comboID);
    }
    catch (e) { }
    //    alert(4);
    try {
        ClearAllItemsRelatedRCB_ChuongTrinh(comboID)
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_LoaiNguoiDung(comboID)
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_ThangLuong(comboID);
    }
    catch (e) { }
    try {
        ClearAllItemsRelatedRCB_ThangLuongMem(comboID);
    }
    catch (e) { }
    try {
        ClearAllItemsRelatedRCB_LienChiDoan(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_GroupID(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_LSTrainingSubjectID(comboID)
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_LoaiNguonBaoBH(comboID);
    }
    catch (e) { }
    try {
        ClearAllItemsRelatedRCB_NguonBaoBH(comboID);
    }
    catch (e) { }
    //Nguyen nhan TNLĐ
    try {
        ClearAllItemsRelatedRCB_NguyenNhanTNLD(comboID);
    }
    catch (e) { }
    //Nhóm yếu tố chấn thương
    try {
        ClearAllItemsRelatedRCB_NhomYeuToChanThuong(comboID);
    }
    catch (e) { }

    //Nhom benh nghe nghiep
    try {
        ClearAllItemsRelatedRCB_NhomBenhNgheNghiep(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_PhanHe_DyNTmp(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_TenBaoCao_DyNTmp(comboID);
    }
    catch (e) { }
    //SIGroupType
    try {
        ClearAllItemsRelatedRCB_SIGroupType(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_RERecruitTypeID(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_NoiDungBHLD(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_LSTrainingTopicID(comboID);
    }
    catch (e) { }

    try // TrangNT: Loai nguon tuyen dung
    {
        ClearAllItemsRelatedRCB_LoaiNguonTuyenDung(comboID);
    }
    catch (e) { }
    try // TrangNT: DemandAll
    {
        ClearAllItemsRelatedRCB_DemandAll(comboID);
    }
    catch (e) { }

    try // TrangNT: DemandAll
    {
        ClearAllItemsRelatedRCB_ProjectAll(comboID);
    }
    catch (e) { }

    try // DanL : Tournament-Subject
    {
        ClearAllItemsRelatedRCB_TournamentAll(comboID);
    }
    catch (e) { }

    try // Quanbm2: ChucVu
    {
        ClearAllItemsRelatedRCB_ChucVu(comboID);
    }
    catch (e) { }

    try {
        ClearAllItemsRelatedRCB_ProjectList(comboID);
    } catch (e) { }
}

// Hàm được sử dụng cho các RadComboBox sử dụng Load On Demand và ShowMoreResultBox
// Thiết lập context["Text"] cho các RadComboBox và giá trị context["Text"] sẽ được truyền từ Client - Side sang Server - Side
function OnClientItemsRequesting(sender, eventArgs) {
    var context = eventArgs.get_context();
    context["Text"] = sender.get_text();
    GetContextByRCB(sender.get_id(), context);
}


// Lấy về các context liên quan đến LoadOnDemand của RCB
function GetContextByRCB(comboID, context) {//alert('22');
    var str = GetParamsRCBByRCBClientID(comboID);
    if (str != "") // parse str ra các biến TypeOfRCB, DataTextFieldName, DataValueFieldName
    {
        var arrParamsRCB = str.split("$");
        context["TypeOfRCB"] = arrParamsRCB[0];
        context["TextFieldName"] = arrParamsRCB[1];
        context["ValueFieldName"] = arrParamsRCB[2];
    }
}

function Related_OnClientItemsRequesting_ChucDanhDuAn(context, comboID) {
    if (comboID.indexOf("cboChucDanhDuAn") >= 0) {
        context["LSNhomChucDanhDAID"] = RCBS_NhomChucDanhDuAn.get_value();
        context["RelatedString"] = "LSNhomChucDanhDAID='" + RCBS_NhomChucDanhDuAn.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_ProjectVersion(context, comboID) {
    if (comboID.indexOf("cboProjectVersionID") >= 0) {
        context["LSThongTinDuAnID"] = RCBS_DuAnPT.get_value();
        context["RelatedString"] = "LSThongTinDuAnID='" + RCBS_DuAnPT.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}


// OnClientItemsRequesting cho Related RadComboBox Cơ cấu
function Related_OnClientItemsRequesting_Org(context, comboID) {
    if (comboID.indexOf("CompanyID") >= 0) {
        if (RCBS_LSOfficeTypeID != null) {
            context["LSOfficeTypeID"] = RCBS_LSOfficeTypeID.get_value();
            context["RelatedString"] = "LSOfficeTypeID='" + RCBS_LSOfficeTypeID.get_value() + "'";
        }
    }
    // Nếu request được tạo ra từ RadComboBox Leve1l thì sẽ lưu context["ID"] đối với RadComboBox Company
    else if (comboID.indexOf("Level1") >= 0) {
        if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
            context["LSCompanyID"] = RCBS_EmpHeaderSearch1_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpHeaderSearch1_Company.get_value() + "'";
        }
        else if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
            context["LSCompanyID"] = RCBS_EmpHeaderSearch_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpHeaderSearch_Company.get_value() + "'";
        }
        else if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
            context["LSCompanyID"] = RCBS_EmpHeaderSearchSI_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpHeaderSearchSI_Company.get_value() + "'";
        }
        else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
            context["LSCompanyID"] = RCBS_EmpHeaderSearchReport_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpHeaderSearchReport_Company.get_value() + "'";
        }
        else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
            context["LSCompanyID"] = RCBS_EmpSearchSimple_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpSearchSimple_Company.get_value() + "'";
        }
        else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
            context["LSCompanyID"] = RCBS_EmpSearchSimple3_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_EmpSearchSimple3_Company.get_value() + "'";
        }
        else if (comboID.indexOf("TrPlanHeader1") >= 0) {
            context["LSCompanyID"] = RCBS_TrPlanHeader1_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_TrPlanHeader1_Company.get_value() + "'";
        }
        else if (comboID.indexOf("OrgSelectSimple1") >= 0) {
            context["LSCompanyID"] = RCBS_OrgSelectSimple1_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_OrgSelectSimple1_Company.get_value() + "'";
        }

        else if (comboID.indexOf("TrCourseHeader1") >= 0) {
            context["LSCompanyID"] = RCBS_TrCourseHeader1_Company.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_TrCourseHeader1_Company.get_value() + "'";
        }
        else if (comboID.indexOf("OrgSelectSimple_H1") >= 0) {
            context["LSCompanyID"] = RCBS_OrgSelectSimple_H1_cboCompany.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_OrgSelectSimple_H1_cboCompany.get_value() + "'";
        }
        else {
            if (RCBS_Company != null) {
                context["LSCompanyID"] = RCBS_Company.get_value();
                context["RelatedString"] = "LSCompanyID='" + RCBS_Company.get_value() + "'";
            }
            else {
                context["LSCompanyID"] = RCBS_CompanyAll.get_value();
                context["RelatedString"] = "LSCompanyID='" + RCBS_CompanyAll.get_value() + "'";
            }
        }

        GetContextByRCB(comboID, context);
    }
    else {
        // Nếu request được tạo ra từ RadComboBox Leve12 thì sẽ lưu context["ID"] đối với RadComboBox Level1
        if (comboID.indexOf("Level2") >= 0) {
            if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel1ID"] = RCBS_EmpHeaderSearch1_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpHeaderSearch1_Level1.get_value() + "'";
            }
            else
                if (comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel1ID"] = RCBS_TrPlanHeader1_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_TrPlanHeader1_Level1.get_value() + "'";
            }
            else
                if (comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel1ID"] = RCBS_OrgSelectSimple1_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_OrgSelectSimple1_Level1.get_value() + "'";
            }

            else
                if (comboID.indexOf("OrgSelectSimple_H1") >= 0) {
                context["LSLevel1ID"] = RCBS_OrgSelectSimple_H1_cboLevel1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_OrgSelectSimple_H1_cboLevel1.get_value() + "'";
            }
            else
                if (comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel1ID"] = RCBS_TrCourseHeader1_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_TrCourseHeader1_Level1.get_value() + "'";
            }
            else
                if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel1ID"] = RCBS_EmpHeaderSearch_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpHeaderSearch_Level1.get_value() + "'";
            }
            else
                if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
                    context["LSLevel1ID"] = RCBS_EmpHeaderSearchSI_Level1.get_value();
                    context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpHeaderSearchSI_Level1.get_value() + "'";
                }
            else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
                context["LSLevel1ID"] = RCBS_EmpHeaderSearchReport_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpHeaderSearchReport_Level1.get_value() + "'";
            }
            else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
                context["LSLevel1ID"] = RCBS_EmpSearchSimple_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpSearchSimple_Level1.get_value() + "'";
            }
            else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel1ID"] = RCBS_EmpSearchSimple3_Level1.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_EmpSearchSimple3_Level1.get_value() + "'";
            }
            else {
                if (RCBS_Level1 != null) {
                    context["LSLevel1ID"] = RCBS_Level1.get_value();
                    context["RelatedString"] = "LSLevel1ID='" + RCBS_Level1.get_value() + "'";
                }
                else {
                    context["LSLevel1ID"] = RCBS_Level1All.get_value();
                    context["RelatedString"] = "LSLevel1ID='" + RCBS_Level1All.get_value() + "'";
                }
            }
            GetContextByRCB(comboID, context);
        }
        else {
            // Nếu request được tạo ra từ RadComboBox Leve13 thì sẽ lưu context["ID"] đối với RadComboBox Level2
            if (comboID.indexOf("Level3") >= 0) {
                if (comboID.indexOf("EmpHeaderSearch11") >= 0) {
                    context["LSLevel2ID"] = RCBS_EmpHeaderSearch1_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpHeaderSearch1_Level2.get_value() + "'";
                }
                else
                    if (comboID.indexOf("TrPlanHeader1") >= 0) {
                    context["LSLevel2ID"] = RCBS_TrPlanHeader1_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_TrPlanHeader1_Level2.get_value() + "'";
                }
                else
                    if (comboID.indexOf("OrgSelectSimple1") >= 0) {
                    context["LSLevel2ID"] = RCBS_OrgSelectSimple1_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_OrgSelectSimple1_Level2.get_value() + "'";
                }


                else
                    if (comboID.indexOf("TrCourseHeader1") >= 0) {
                    context["LSLevel2ID"] = RCBS_TrCourseHeader1_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_TrCourseHeader1_Level2.get_value() + "'";
                }
                else
                    if (comboID.indexOf("EmpHeaderSearch1") >= 0) {
                    context["LSLevel2ID"] = RCBS_EmpHeaderSearch_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpHeaderSearch_Level2.get_value() + "'";
                }
                else
                    if (comboID.indexOf("EmpHeaderSearchSI1") >= 0) {
                        context["LSLevel2ID"] = RCBS_EmpHeaderSearchSI_Level1.get_value();
                        context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpHeaderSearchSI_Level2.get_value() + "'";
                    }
                else if (comboID.indexOf("EmpHeaderSearchReport1") >= 0) {
                    context["LSLevel2ID"] = RCBS_EmpHeaderSearchReport_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpHeaderSearchReport_Level2.get_value() + "'";
                }
                else if (comboID.indexOf("EmpSearchSimple1") >= 0) {
                    context["LSLevel2ID"] = RCBS_EmpSearchSimple_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpSearchSimple_Level2.get_value() + "'";
                }
                else if (comboID.indexOf("EmpSearchSimple3") >= 0) {
                    context["LSLevel2ID"] = RCBS_EmpSearchSimple3_Level2.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_EmpSearchSimple3_Level2.get_value() + "'";
                }
                else {
                    if (RCBS_Level2 == null) {
                        context["LSLevel2ID"] = RCBS_Level2All.get_value();
                        context["RelatedString"] = "LSLevel2ID='" + RCBS_Level2All.get_value() + "'";
                    }
                    else {
                        context["LSLevel2ID"] = RCBS_Level2.get_value();
                        context["RelatedString"] = "LSLevel2ID='" + RCBS_Level2.get_value() + "'";
                    }
                }
                GetContextByRCB(comboID, context);
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel3ID"] = RCBS_EmpHeaderSearch1_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_EmpHeaderSearch1_Level3.get_value() + "'";
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel4ID"] = RCBS_EmpHeaderSearch1_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_EmpHeaderSearch1_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel5ID"] = RCBS_EmpHeaderSearch1_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_EmpHeaderSearch1_Level5.get_value() + "'";
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel6ID"] = RCBS_EmpHeaderSearch1_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_EmpHeaderSearch1_Level6.get_value() + "'";
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel7ID"] = RCBS_EmpHeaderSearch1_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_EmpHeaderSearch1_Level7.get_value() + "'";
            }
            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("EmpHeaderSearch11") >= 0) {
                context["LSLevel8ID"] = RCBS_EmpHeaderSearch1_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_EmpHeaderSearch1_Level8.get_value() + "'";
            }

            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel3ID"] = RCBS_EmpHeaderSearch_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_EmpHeaderSearch_Level3.get_value() + "'";
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel4ID"] = RCBS_EmpHeaderSearch_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_EmpHeaderSearch_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel5ID"] = RCBS_EmpHeaderSearch_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_EmpHeaderSearch_Level5.get_value() + "'";
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel6ID"] = RCBS_EmpHeaderSearch_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_EmpHeaderSearch_Level6.get_value() + "'";
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel7ID"] = RCBS_EmpHeaderSearch_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_EmpHeaderSearch_Level7.get_value() + "'";
            }
            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("EmpHeaderSearch1") >= 0) {
                context["LSLevel8ID"] = RCBS_EmpHeaderSearch_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_EmpHeaderSearch_Level8.get_value() + "'";
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel3ID"] = RCBS_EmpSearchSimple3_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_EmpSearchSimple3_Level3.get_value() + "'";
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel4ID"] = RCBS_EmpSearchSimple3_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_EmpSearchSimple3_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel5ID"] = RCBS_EmpSearchSimple3_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_EmpSearchSimple3_Level5.get_value() + "'";
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel6ID"] = RCBS_EmpSearchSimple3_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_EmpSearchSimple3_Level6.get_value() + "'";
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel7ID"] = RCBS_EmpSearchSimple3_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_EmpSearchSimple3_Level7.get_value() + "'";
            }
            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("EmpSearchSimple3") >= 0) {
                context["LSLevel8ID"] = RCBS_EmpSearchSimple3_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_EmpSearchSimple3_Level8.get_value() + "'";
            }
            //
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel3ID"] = RCBS_TrPlanHeader1_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_TrPlanHeader1_Level3.get_value() + "'";
            }
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel3ID"] = RCBS_OrgSelectSimple1_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_OrgSelectSimple1_Level3.get_value() + "'";
            }

            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel4ID"] = RCBS_TrPlanHeader1_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_TrPlanHeader1_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel4ID"] = RCBS_OrgSelectSimple1_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_OrgSelectSimple1_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel5ID"] = RCBS_TrPlanHeader1_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_TrPlanHeader1_Level5.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel5ID"] = RCBS_OrgSelectSimple1_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_OrgSelectSimple1_Level5.get_value() + "'";
            }

            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel6ID"] = RCBS_TrPlanHeader1_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_TrPlanHeader1_Level6.get_value() + "'";
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel6ID"] = RCBS_OrgSelectSimple1_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_OrgSelectSimple1_Level6.get_value() + "'";
            }

            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel7ID"] = RCBS_TrPlanHeader1_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_TrPlanHeader1_Level7.get_value() + "'";
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel7ID"] = RCBS_OrgSelectSimple1_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_OrgSelectSimple1_Level7.get_value() + "'";
            }

            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("TrPlanHeader1") >= 0) {
                context["LSLevel8ID"] = RCBS_TrPlanHeader1_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_TrPlanHeader1_Level8.get_value() + "'";
            }
            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("OrgSelectSimple1") >= 0) {
                context["LSLevel8ID"] = RCBS_OrgSelectSimple1_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_OrgSelectSimple1_Level8.get_value() + "'";
            }

            //
            else if (comboID.indexOf("Level4") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel3ID"] = RCBS_TrCourseHeader1_Level3.get_value();
                context["RelatedString"] = "LSLevel3ID='" + RCBS_TrCourseHeader1_Level3.get_value() + "'";
            }
            else if (comboID.indexOf("Level5") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel4ID"] = RCBS_TrCourseHeader1_Level4.get_value();
                context["RelatedString"] = "LSLevel4ID='" + RCBS_TrCourseHeader1_Level4.get_value() + "'";
            }
            else if (comboID.indexOf("Level6") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel5ID"] = RCBS_TrCourseHeader1_Level5.get_value();
                context["RelatedString"] = "LSLevel5ID='" + RCBS_TrCourseHeader1_Level5.get_value() + "'";
            }
            else if (comboID.indexOf("Level7") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel6ID"] = RCBS_TrCourseHeader1_Level6.get_value();
                context["RelatedString"] = "LSLevel6ID='" + RCBS_TrCourseHeader1_Level6.get_value() + "'";
            }
            else if (comboID.indexOf("Level8") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel7ID"] = RCBS_TrCourseHeader1_Level7.get_value();
                context["RelatedString"] = "LSLevel7ID='" + RCBS_TrCourseHeader1_Level7.get_value() + "'";
            }
            else if (comboID.indexOf("Level9") >= 0 && comboID.indexOf("TrCourseHeader1") >= 0) {
                context["LSLevel8ID"] = RCBS_TrCourseHeader1_Level8.get_value();
                context["RelatedString"] = "LSLevel8ID='" + RCBS_TrCourseHeader1_Level8.get_value() + "'";
            }
            GetContextByRCB(comboID, context);
        }
    }
}

function Related_OnClientItemsRequesting_Org_(context, comboID) {
    // Nếu request được tạo ra từ RadComboBox Leve1l thì sẽ lưu context["ID"] đối với RadComboBox Company
    if (comboID.indexOf("Level1ID_") >= 0) {
        if (RCBS_Company_ != null) {
            context["LSCompanyID"] = RCBS_Company_.get_value();
            context["RelatedString"] = "LSCompanyID='" + RCBS_Company_.get_value() + "'";
        }
        GetContextByRCB(comboID, context);
    }
    else {
        // Nếu request được tạo ra từ RadComboBox Leve12 thì sẽ lưu context["ID"] đối với RadComboBox Level1
        if (comboID.indexOf("Level2ID_") >= 0) {
            if (RCBS_Level1_ != null) {
                context["LSLevel1ID"] = RCBS_Level1_.get_value();
                context["RelatedString"] = "LSLevel1ID='" + RCBS_Level1_.get_value() + "'";
            }
            GetContextByRCB(comboID, context);
        }
        else {
            // Nếu request được tạo ra từ RadComboBox Leve13 thì sẽ lưu context["ID"] đối với RadComboBox Level2
            if (comboID.indexOf("Level3ID_") >= 0) {
                if (RCBS_Level2_ != null) {
                    context["LSLevel2ID"] = RCBS_Level2_.get_value();
                    context["RelatedString"] = "LSLevel2ID='" + RCBS_Level2_.get_value() + "'";
                }
                GetContextByRCB(comboID, context);
            }
        }
    }
}
// OnClientItemsRequesting cho Related RadComboBox Province
function Related_OnClientItemsRequesting_Province(context, comboID) {
    if (comboID.indexOf("cboP_District") >= 0) {
        context["LSProvinceID"] = RCBS_P_Province.get_value();
        context["RelatedString"] = "LSProvinceID='" + RCBS_P_Province.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
    else
        if (comboID.indexOf("cboT_District") >= 0) {
        context["LSProvinceID"] = RCBS_T_Province.get_value();
        context["RelatedString"] = "LSProvinceID='" + RCBS_T_Province.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
    else if (comboID.indexOf("CboT_District_") >= 0) {
        context["LSProvinceID"] = RCBS_T_Province.get_value();
        context["RelatedString"] = "LSProvinceID='" + RCBS_T_Province.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}
// OnClientItemsRequesting cho Related RadComboBox cboP_Ward
function Related_OnClientItemsRequesting_District(context, comboID) {
    if (comboID.indexOf("cboP_Ward") >= 0) {
        context["LSDistrictID"] = RCBS_P_District.get_value();
        context["RelatedString"] = "LSDistrictID='" + RCBS_P_District.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}
// OnClientItemsRequesting cho Related RadComboBox cboT_Ward
function Related_OnClientItemsRequesting_T_District(context, comboID) {
    if (comboID.indexOf("cboT_Ward") >= 0) {
        context["LSDistrictID"] = RCBS_T_District.get_value();
        context["RelatedString"] = "LSDistrictID='" + RCBS_T_District.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

// OnClientItemsRequesting cho Related RadComboBox Bank
function Related_OnClientItemsRequesting_Bank(context, comboID) {
    if (comboID.indexOf("cboLSBankBranchID") >= 0) {
        if (comboID.indexOf("_Second") >= 0) {
            context["LSBankID"] = RCBS_Bank_Second.get_value();
            context["RelatedString"] = "LSBankID='" + RCBS_Bank_Second.get_value() + "'";
            GetContextByRCB(comboID, context);
        }
        else {
            context["LSBankID"] = RCBS_Bank.get_value();
            context["RelatedString"] = "LSBankID='" + RCBS_Bank.get_value() + "'";
            GetContextByRCB(comboID, context);
        }
    }
}

// OnClientItemsRequesting cho Related RadComboBox Template LinkServer
function Related_OnClientItemsRequesting_TemplateLinkServer(context, comboID) {
    if (comboID.indexOf("cboLSTypeDataLinkServerID") >= 0) {
        context["LSTemplateLinkServerID"] = RCBS_TemplateLinkServer.get_value();
        context["RelatedString"] = "LSTemplateLinkServerID='" + RCBS_TemplateLinkServer.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

// OnClientItemsRequesting cho Related RadComboBox Nhóm Chi Phi Hanh Chinh
function Related_OnClientItemsRequesting_NhomChiPhiHanhChinh(context, comboID) {
    if (comboID.indexOf("cboLSChiPhiHanhChinhID") >= 0) {
        context["LSNhomChiPhiHanhChinhID"] = RCBS_NhomChiPhiHanhChinh.get_value();
        context["RelatedString"] = "LSNhomChiPhiHanhChinhID='" + RCBS_NhomChiPhiHanhChinh.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

// OnClientItemsRequesting cho Related RadComboBox Loai San Pham
function Related_OnClientItemsRequesting_LoaiSanPham(context, comboID) {
    if (comboID.indexOf("cboLSCongDoanSXID") >= 0) {
        context["LSLoaiSanPhamID"] = RCBS_LoaiSanPham.get_value();
        context["RelatedString"] = "LSLoaiSanPhamID='" + RCBS_LoaiSanPham.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_SkillGroup(context, comboID) {
    if (comboID.indexOf("cboLSSkillTypeID") >= 0) {
        context["LSSkillGroupID"] = RCBS_SkillGroup.get_value();
        context["RelatedString"] = "LSSkillGroupID='" + RCBS_SkillGroup.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_SkillType(context, comboID) {
    if (comboID.indexOf("cboLSEmpSkillID") >= 0) {
        context["LSSkillTypeID"] = RCBS_SkillType.get_value();
        context["RelatedString"] = "LSSkillTypeID='" + RCBS_SkillType.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

/// OnClientItemsRequesting cho Related RadComboBox ProfessionalLevelType
function Related_OnClientItemsRequesting_ProfessionalLevelType(context, comboID) {
    if (comboID.indexOf("cboLSTrainingRangeID") >= 0) {
        context["LSProfessionalLevelTypeID"] = RCBS_ProfessionalLevelType.get_value();
        context["RelatedString"] = "LSProfessionalLevelTypeID='" + RCBS_ProfessionalLevelType.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}
function Related_OnClientItemsRequesting_BangLuong(context, comboID) {
    if (RCBS_BangLuong != null) {
        if (comboID.indexOf("cboThangLuong") >= 0) {
            context["LSBangLuongID"] = RCBS_BangLuong.get_value();
            context["RelatedString"] = "LSBangLuongID='" + RCBS_BangLuong.get_value() + "'";
            GetContextByRCB(comboID, context);
        }
    }
    else if (RCBS_BangLuongMem != null) {
        Related_OnClientItemsRequesting_BangLuongMem(context, comboID);
    }
}
function Related_OnClientItemsRequesting_BangLuongMem(context, comboID) {
    if (comboID.indexOf("cboThangLuongMem") >= 0) {
        context["LSBangLuongMemID"] = RCBS_BangLuongMem.get_value();
        context["RelatedString"] = "LSBangLuongMemID='" + RCBS_BangLuongMem.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_UserType(context, comboID) {
    if (comboID.indexOf("cboNhomNguoiDung") >= 0) {
        context["MaLoaiNguoiDung"] = RCBS_UserType.get_value();
        context["RelatedString"] = "MaLoaiNguoiDung='" + RCBS_UserType.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_APPYear(context, comboID) {
    if ((comboID.indexOf("cboAPPPeriod") >= 0 && comboID.indexOf("cboAPPPeriod_") < 0) || comboID.indexOf("cboOpenAPPPeriod") >= 0) {
        context["Year"] = RCBS_APPYear.get_value();
        context["RelatedString"] = "Year='" + RCBS_APPYear.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_APPYear_(context, comboID) {
    if (comboID.indexOf("cboAPPPeriod_") >= 0) {
        context["Year"] = RCBS_APPYear_.get_value();
        context["RelatedString"] = "Year='" + RCBS_APPYear_.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_APPPeriod(context, comboID) {
    if (comboID.indexOf("cboAPPSubject") >= 0) {
        context["APPPeriodID"] = RCBS_APPPeriod.get_value();
        context["RelatedString"] = "APPPeriodID='" + RCBS_APPPeriod.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_Nam(context, comboID) {
    if (comboID.indexOf("cboAPPKyDanhGiaHanhViID") >= 0 ) {
        context["Nam"] = RCBS_Nam.get_value();
        context["RelatedString"] = "Nam='" + RCBS_Nam.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function ClearAllItemsRelatedRCB_Nam(comboID) {
    if (comboID.indexOf("cboNam") >= 0) {
        try {
            RCBS_APPKyDanhGiaHanhViID.set_text("");
            RCBS_APPKyDanhGiaHanhViID.clearItems();
        } catch (err) { }
        try {
            RCBS_APPKyDanhGiaHanhViID.set_text("");
            RCBS_APPKyDanhGiaHanhViID.clearItems();
        } catch (err) { }
    }
}

function Related_OnClientItemsRequesting_NamKH(context, comboID) {
    if (comboID.indexOf("cboKyKeHoachPhatTrienBanThanID") >= 0 ) {
        context["Nam"] = RCBS_NamKH.get_value();
        context["RelatedString"] = "Nam='" + RCBS_NamKH.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function ClearAllItemsRelatedRCB_NamKH(comboID) {
    if (comboID.indexOf("cboNamKH") >= 0) {
        try {
            RCBS_KyKeHoachPhatTrienBanThanID.set_text("");
            RCBS_KyKeHoachPhatTrienBanThanID.clearItems();
        } catch (err) { }
        try {
            RCBS_KyKeHoachPhatTrienBanThanID.set_text("");
            RCBS_KyKeHoachPhatTrienBanThanID.clearItems();
        } catch (err) { }
    }
}

function Related_OnClientItemsRequesting_JobCodeGroup(context, comboID) {
    if (comboID.indexOf("cboLSJobCodeID") >= 0) {
        context["LSJobCodeGroupID"] = RCBS_JobCodeGroup.get_value();
        context["RelatedString"] = "LSJobCodeGroupID='" + RCBS_JobCodeGroup.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_ProjectList(context, comboID) {
    if (comboID.indexOf("cboLSLenhSanXuat") >= 0) {
        context["LSProjectListID"] = RCBS_DuAn.get_value();
        context["RelatedString"] = "LSProjectListID='" + RCBS_DuAn.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}

function Related_OnClientItemsRequesting_JobCode(context, comboID) {
    if (comboID.indexOf("cboLSJobTypeID") >= 0) {
        context["LSJobCodeID"] = RCBS_JobCode.get_value();
        context["RelatedString"] = "LSJobCodeID='" + RCBS_JobCode.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}
//----Chức vụ + Chức danh
function Related_OnClientItemsRequesting_JobFunction(context, comboID) {
    if (comboID.indexOf("cboLSJobTitleID_Related") >= 0) {
        context["LSChucVuID"] = RCBS_JobFunction.get_value();
        context["RelatedString"] = "LSChucVuID='" + RCBS_JobFunction.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}
//----End Chức vụ + Chức danh

function Related_OnClientItemsRequesting_NhomCongViec(context, comboID) {
    if (comboID.indexOf("cboLSLoaiNoiDungCVID") >= 0) {
        context["LSNhomNoiDungCVID"] = RCBS_NhomCongViec.get_value();
        context["RelatedString"] = "LSNhomNoiDungCVID='" + RCBS_NhomCongViec.get_value() + "'";
        GetContextByRCB(comboID, context);
    }
}


//--Nội dung BHLD
function Related_OnClientItemsRequesting_NoiDungBHLD(context, comboID) {
    if (comboID.indexOf("cboNoiDungBHLD") >= 0) {
        context["LoaiBHLD"] = RCBS_LoaiBHLD.get_value();
    }
}
function ClearAllItemsRelatedRCB_NoiDungBHLD(comboID) {
    if (comboID.indexOf("cboLoaiBHLD") >= 0) {
        RCBS_NoiDungBHLD.set_text("");
        RCBS_NoiDungBHLD.clearItems();
    }
}
//---------------

//--Traning topic for TrPlanHeader1 a92nd TrCourseHeader1
function Related_OnClientItemsRequesting_LSTrainingTopicID(context, comboID) {

    if (comboID.indexOf("cboLSTrainingTopicID") >= 0) {
        if (RCBS_TrainingField != null)
            context["TrainingField"] = RCBS_TrainingField.get_value();
        if (RCBS_TrainingField_ != null)
            context["TrainingField"] = RCBS_TrainingField_.get_value();
    }
}
function ClearAllItemsRelatedRCB_LSTrainingTopicID(comboID) {
    if (comboID.indexOf("cboLSTrainingFieldID") >= 0) {
        if (RCBS_TrainingField != null) {
            RCBS_TrainingTopic.set_text("");
            RCBS_TrainingTopic.clearItems();
        }
        if (RCBS_TrainingField_ != null) {
            RCBS_TrainingTopic_.set_text("");
            RCBS_TrainingTopic_.clearItems();
        }

        if (RCBS_TrainingField2140 != null) {
            RCBS_TrainingTopic2140.set_text("");
            RCBS_TrainingTopic2140.clearItems();
        }
    }
}
//---------------

// OnClientItemsRequesting cho Related RadComboBox 
function Related_OnClientItemsRequesting_NhomCCDC(context, comboID) {

    if (comboID.indexOf("cboNhomCCDC") >= 0) {
        context["LoaiTaiSan"] = RCBS_LoaiTaiSan.get_value();
    }
}

function Related_OnClientItemsRequesting_CCDC(context, comboID) {

    if (comboID.indexOf("cboVPP") >= 0) // cbo child 
    {
        context["NhomCCDC"] = RCBS_NhomTaiSan.get_value(); // tạo key : tự đặt

    }
}

//Cbo LoaiNguonBao
function Related_OnClientItemsRequesting_LoaiNguonBaoBH(context, comboID) {
    if (comboID.indexOf("LoaiNguonBaoBH") >= 0) {
        context["MaBoMauBH"] = RCBS_BoMauBH.get_value();
    }
}
//Cbo NguonBao
function Related_OnClientItemsRequesting_NguonBaoBH(context, comboID) {
    //debugger;
    if (RCBS_BoMauBH == null)
        RCBS_BoMauBH = $find("_ctl0_cboBoMauBH");
    if (comboID.indexOf("cboSource") >= 0 && RCBS_LoaiNguonBaoBH != null && RCBS_LoaiNguonBaoBH.get_value() != "") {
        context["MaLoaiNguonBaoBH"] = RCBS_LoaiNguonBaoBH.get_value();
        context["MaBoMauBH"] = RCBS_BoMauBH.get_value();
    }
    else if (comboID.indexOf("cboSource") >= 0 && (RCBS_LoaiNguonBaoBH == null || RCBS_LoaiNguonBaoBH.get_value() == "")) {
        context["MaBoMauBH"] = RCBS_BoMauBH == null ? '' : RCBS_BoMauBH.get_value();
    }
}
//Nhom nguyen nhan TNLĐ
function Related_OnClientItemsRequesting_NhomNguyenNhanTNLD(context, comboID) {
    if (comboID.indexOf("NguyenNhanTNLD") >= 0) {
        context["LSNhomNguyenNhanTNLDID"] = RCBS_NhomNguyenNhanTNLD.get_value();
    }
}

//Nhom yeu to chan thuong
function Related_OnClientItemsRequesting_NhomYeuToChanThuong(context, comboID) {
    if (comboID.indexOf("YeuToChanThuong") >= 0) {
        context["LSNhomYeuToChanThuongID"] = RCBS_NhomYeuToChanThuong.get_value();
    }
}

//Nhom Benh nghe nghiep
function Related_OnClientItemsRequesting_NhomBenhNgheNghiep(context, comboID) {
    if (comboID.indexOf("BenhNgheNghiep") >= 0) {
        context["LSNhomBenhNgheNghiepID"] = RCBS_NhomBenhNgheNghiep.get_value();
    }
}

//PhanHe_DyNTmp
function Related_OnClientItemsRequesting_PhanHe_DyNTmp(context, comboID) {
    if (comboID.indexOf("TenBaoCao_DyNTmp") >= 0) {
        context["PhanHe_DyNTmp"] = RCBS_PhanHe_DyNTmp.get_value();
    }
}

//TenBaoCao_DyNTmp
function Related_OnClientItemsRequesting_TenBaoCao_DyNTmp(context, comboID) {
    if (comboID.indexOf("LoaiThongTin_DyNTmp") >= 0) {
        context["TenBaoCao_DyNTmp"] = RCBS_TenBaoCao_DyNTmp.get_value();
    }
}

//SIGroupType
function Related_OnClientItemsRequesting_SIGroupType(context, comboID) {
    if (comboID.indexOf("SIGroupType") >= 0) {
        context["SIGroupTypeID"] = RCBS_SIGroupType.get_value();
    }
}

function GetFunctionID() {
    var txtFunc = document.getElementById("txtFunctionID");
    var FunctionID = "";
    if (txtFunc != null) {
        FunctionID = txtFunc.value;
    }
    return FunctionID
}

// Hàm được sử dụng cho các RadComboBox CƠ CẤU sử dụng Load On Demand và ShowMoreResultBox 
// Thiết lập giá trị context["ID"] đối với RadComboBox "Parent" của RadComboBox tạo nên request
// giá trị này sẽ được chuyển vào Server - Side cho các hàm ItemsRequested để sử dụng
function Related_OnClientItemsRequesting(sender, eventArgs) {
    // Khởi tạo các biến cho các related RadComboBox cơ cấu
    InitRCB();
    var context = eventArgs.get_context();
    // Thiết lập context["Text"] cho RadComboBox thực hiện request
    context["Text"] = sender.get_text();
    // Thiết lập context["ID"] đối với các RadComboBox "Parent"
    var comboID = sender.get_id();
    // Related_OnClientItemsRequesting cho Related RadComboBox Cơ cấu
    //lay functionID tren giao dien de load org
    context["FunctionID"] = GetFunctionID();

    //Kiểm tra xem combo rerate có setup combo cha hay không? Nếu có thì relate, còn không thì làm như bình thường.
    try {
        if (sender != null) {
            //quanbm2 : 2014-05-31: load com bo được chỉ định
            var ObjectID = sender.get_attributes().getAttribute("relateObjectID");
            var relateColumn = sender.get_attributes().getAttribute("relateColumn");

            var cboRelate = $find(ObjectID);
            if (cboRelate != null) {
                var relateValue = cboRelate.get_value();
                context[relateColumn] = relateValue;
                context["RelatedString"] = (relateColumn + "='" + relateValue + "'");

                GetContextByRCB(comboID, context);
            }
            else {

                try { // Lam tv2
                    Related_OnClientItemsRequesting_Org(context, comboID);
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_Org_(context, comboID);
                }
                catch (e) { }
                Related_OnClientItemsRequesting_ChucDanhDuAn(context, comboID);
                // Related_OnClientItemsRequesting cho Related RadComboBox Province
                Related_OnClientItemsRequesting_Province(context, comboID);
                //////////Phuong/Xa///////////////////////////////////////
                Related_OnClientItemsRequesting_District(context, comboID);
                Related_OnClientItemsRequesting_T_District(context, comboID);
                // Related_OnClientItemsRequesting cho Related RadComboBox Bank
                Related_OnClientItemsRequesting_Bank(context, comboID);
                Related_OnClientItemsRequesting_TemplateLinkServer(context, comboID);
                Related_OnClientItemsRequesting_NhomChiPhiHanhChinh(context, comboID);
                Related_OnClientItemsRequesting_LoaiSanPham(context, comboID);
                Related_OnClientItemsRequesting_SkillGroup(context, comboID);
                Related_OnClientItemsRequesting_SkillType(context, comboID);
                Related_OnClientItemsRequesting_ProfessionalLevelType(context, comboID);
                Related_OnClientItemsRequesting_BangLuong(context, comboID);
                Related_OnClientItemsRequesting_BangLuongMem(context, comboID);
                Related_OnClientItemsRequesting_UserType(context, comboID);
                Related_OnClientItemsRequesting_NhomCCDC(context, comboID);
                Related_OnClientItemsRequesting_CCDC(context, comboID);

                //Nội dung BHLD
                Related_OnClientItemsRequesting_NoiDungBHLD(context, comboID);

                //TrainingTopic
                Related_OnClientItemsRequesting_LSTrainingTopicID(context, comboID);

                //Job Code Group + Job Code + Loại công việc
                Related_OnClientItemsRequesting_JobCodeGroup(context, comboID);
                Related_OnClientItemsRequesting_JobCode(context, comboID);

                //Dự án + Lệnh sản xuất
                Related_OnClientItemsRequesting_ProjectList(context, comboID);

                //Chức vụ + Chức danh
                Related_OnClientItemsRequesting_JobFunction(context, comboID);
                //Nhóm + Loại công việc
                Related_OnClientItemsRequesting_NhomCongViec(context, comboID);
                //Năm + Kỳ đánh giá
                Related_OnClientItemsRequesting_APPYear(context, comboID);
                Related_OnClientItemsRequesting_APPYear_(context, comboID);
                
                Related_OnClientItemsRequesting_Nam(context, comboID);
                Related_OnClientItemsRequesting_NamKH(context, comboID);
                //Kỳ đánh giá + Đối tượng đánh giá
                Related_OnClientItemsRequesting_APPPeriod(context, comboID);

                // Lamtv2 begin     
                try {
                    Related_OnClientItemsRequesting_CongTy(context, comboID);
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_DonVi(context, comboID);
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_PhongBan(context, comboID);

                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_ToNhom(context, comboID); //

                }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level4(context, comboID); }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level5(context, comboID); }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level6(context, comboID); }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level7(context, comboID); }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level8(context, comboID); }
                catch (e) { }
                try { Related_OnClientItemsRequesting_Level9(context, comboID); }
                catch (e) { }

                try { Related_OnClientItemsRequesting_HLevel(context, comboID); }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_MonHoc(context, comboID); //
                }
                catch (e) { }


                try {
                    Related_OnClientItemsRequesting_LopHoc(context, comboID); // 
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_KhoaDT(context, comboID); //
                }
                catch (e) { }
                try {

                    Related_OnClientItemsRequesting_MonHoc(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_LoaiNguoiDung(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_CopyPer(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_GroupID(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_UserID(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_dlModule(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_NgachLuong(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_NgachLuongMem(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_ChiDoan(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_BacLuong(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_BacLuongMem(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_PhanDoan(context, comboID); //
                }
                catch (e) { }
                //TrangNT

                try {
                    Related_OnClientItemsRequesting_LoaiNguonBaoBH(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_NguonBaoBH(context, comboID); //
                }
                catch (e) { }
                //Nhom nguyen nhan TNLĐ
                try {
                    Related_OnClientItemsRequesting_NhomNguyenNhanTNLD(context, comboID); //
                }
                catch (e) { }
                //Nhom yeu to chan thuong
                try {
                    Related_OnClientItemsRequesting_NhomYeuToChanThuong(context, comboID); //
                }
                catch (e) { }
                //Nhom benh nghe nghiep
                try {
                    Related_OnClientItemsRequesting_NhomBenhNgheNghiep(context, comboID); //
                }
                catch (e) { }

                //PhanHe_DyNTmp
                try {
                    Related_OnClientItemsRequesting_PhanHe_DyNTmp(context, comboID); //
                }
                catch (e) { }

                //TenBaoCao_DyNTmp
                try {
                    Related_OnClientItemsRequesting_TenBaoCao_DyNTmp(context, comboID); //
                }
                catch (e) { }

                //Related_OnClientItemsRequesting_SIGroupType
                try {
                    Related_OnClientItemsRequesting_SIGroupType(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_Date(context, comboID); //
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_NguoiYeuCau(context, comboID); //
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_BacLuongSTB(context, comboID);
                }
                catch (e) { }
                try {
                    Related_OnClientItemsRequesting_NguonTuyenDung(context, comboID);
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_Project(context, comboID);
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_ProjectTournament(context, comboID);
                }
                catch (e) { }

                try {
                    Related_OnClientItemsRequesting_TournamentSubject(context, comboID);
                } catch (e) { }

                try {
                    Related_OnClientItemsRequesting_TournamentIntContent(context, comboID);
                } catch (e) { }
                try {
                    Related_OnClientItemsRequesting_ProjectVersion(context, comboID);
                } catch (e) { }
            }
        }
    }
    catch (e) { }


}

// Hàm thông báo khi user chọn item của RadComboBox có text <KSD> hoặc <not used>
function OnSelectedIndexChanged(sender, eventArgs) {
    var comboText = sender.get_text();
    SelectedIndexChanged(comboText);
}

function OnFocus(sender, eventArgs) {
    // force rcb to show dropdown
    sender.showDropDown();
    var comboText = sender.get_text();
    SelectedIndexChanged(comboText);
}


// Hàm thông báo khi user chọn item của RadComboBox có text <KSD> hoặc <not used>
function SelectedIndexChanged(comboText) {
    var sCompare = comboText.substring(comboText.length - 10, comboText.length);
    var sCompareVN = comboText.substring(comboText.length - 5, comboText.length);
    if (sCompare == '<not used>') {
        GetAlertTextPopUp('This selected value not used in list!')
    }
    if (sCompareVN == '<KSD>') {
        GetAlertTextPopUp('Mục chọn không được sử dụng trong danh sách!')
    }
}


// Hàm sẽ được sử dụng khi user blur ra khỏi RadComboBox
// Mục tiêu: Thiết lập item đầu tiên được tìm thấy sau khi user filter text và blur khỏi RadComboBox
//           Nếu không tồn tại item nào được tìm thấy sau khi user filter text thì sẽ thiết lập giá trị rỗng
function OnClientBlur(sender, eventArgs) {
    // Nếu user thực hiện filter text trên RadComboBox thì sẽ áp dụng trường hợp này
    // Ngược lại thì sẽ không thực hiện bất cứ gì
    // Khi user filter text trên RadComboBox, items list tương ứng với text này sẽ được show ra
    // Tuy nhiên, do user chưa chọn bất kỳ một item tồn tại trong list này, do đó get_value() vẫn là empty
    // Nếu user dùng mouse để click vào 1 item hoặc user enter thì lúc này get_value sẽ có giá trị khác với empty
    if ((sender.get_value() == "") && (sender.get_text() != "")) // edited by ThanhDC 28/02/2011 - Áp dụng cho trường hợp chưa filter text nào trên area field
    {
        var i;
        // biến dùng để đánh dấu xem là có tồn tại items list tương ứng với filter text hay không?
        // Nếu không tồn tại items list tương ứng thì flag = false, ngược lại flag = true
        var flag = false;
        var text;
        var selectedItem;

        if (sender.get_childListElement() != null) {
            // Duyệt qua tất cả các item trong items list của RadComboBox
            for (i = 0; i < sender.get_childListElement().children.length; i++) {
                // Lưu ý: Ngay lúc ban đầu khi load dữ liệu cho RadComboBox và user toggle vào RadComboBox để show các items ra
                // thì lúc này các item này có display = ""
                // Sau đó user filter text vào input area thì RadComboBox sẽ hiển thị các items tương ứng với filter text đó
                // CÁC ITEMS MÀ KHÔNG TƯƠNG ỨNG VỚI FILTER TEXT SẼ ĐƯỢC CHUYỂN DISPLAY VỀ NONE (DISPLAY = "NONE")
                // Do đó, ở trường hợp onblur này, chỉ cần xét các items có display = "" mà thôi, bỏ qua các items có display = "none"
                if (sender.get_childListElement().children[i].style.display == "") {
                    // Lấy về item đầu tiên có display = "" trong items list được show ra
                    selectedItem = sender.findItemByText(sender.get_childListElement().children[i].innerText);
                    // Thiết lập SelectedItem này cho RadComboBox
                    if (selectedItem != null) {
                        selectedItem.select();
                        // Đánh dấu tồn tại items list tương ứng với filter text
                        flag = true;

                        // Thoát ngay sau khi thiết lập SelectedItem cho RadComboBox, không quan tâm đến các items phía sau
                        break;
                    }
                    else // trường hợp RCB sử dụng Web Service để load dữ liệu 
                    {
                        // lúc này ký tự < được trả về có dạng &lt; nên cần phải replace lại cho đúng
                        // như vậy sẽ có phát sinh trường hợp sử dụng nhiều ký tự đặc biệt cho text này
                        // cần phải xác định lại thật kỹ tại đây
                        text = sender.get_childListElement().children[i].innerText.replace("<", "&lt;");
                        selectedItem = sender.findItemByText(text);
                        if (selectedItem != null) {
                            selectedItem.select();
                            // Đánh dấu tồn tại items list tương ứng với filter text
                            flag = true;

                            // Thoát ngay sau khi thiết lập SelectedItem cho RadComboBox, không quan tâm đến các items phía sau
                            break;
                        }
                    }
                }
            }
        }

        // Nếu không tồn tại items list tương ứng với filter Text được nhập vào
        // thì sẽ xóa trắng text và selection của RadComboBox

        if (!flag) {
            sender.set_text("");
            sender.clearSelection();
        }
    }
}

// Sau khi các items được load xong, sẽ thiết lập filterText bằng chính text đang hiển thị trên input area của RadComboBox
// Mục tiêu: Sau khi user filter text hoặc chọn 1 item nào đó thì sau đó user toggle vào RadComboBox 
//           SẼ CHỈ HIỂN THỊ CÁC ITEMS TƯƠNG ỨNG VỚI TEXT ĐANG HIỂN THỊ TRÊN RADCOMBOBOX
function OnItemsLoaded(sender, eventArgs) {
    var items = sender.get_items();
    var count = items.get_count();
    for (var i = 0; i < count; i++) {
        var comboText = items.getItem(i).get_text().replace("&lt;", "<").replace("&gt;", ">");
        var sCompare = comboText.substring(comboText.length - 10, comboText.length);
        var sCompareVN = comboText.substring(comboText.length - 5, comboText.length);
        if (document.getElementById("txtDoiMauCombo") != null) {
            if (document.getElementById("txtDoiMauCombo").value == "1") {
                if (sCompare == '<not used>') {
                    var li = items.getItem(i).get_element();
                    li.style.backgroundColor = "#D3D3D3";
                }
                if (sCompareVN == '<KSD>') {
                    var li = items.getItem(i).get_element();
                    li.style.backgroundColor = "#D3D3D3";
                }
            }
        }
    }
}

// Hàm sẽ được chạy đầu tiên khi page được load
// Dùng để thiết lập các thuộc tính OnClientBlur, OnClientTextChange, OnClientFocus, OnClientSelectedIndexChanged cho các RadComboBox
// Mục tiêu:    Để thông báo message khi user chọn item có chứa chuỗi <KSD> hoặc <not used>
//              Để hiển thị item được tìm thấy đầu tiên dựa trên filter text khi user blur khỏi RadComboBox. Nếu không tìm thấy items list tương ứng
//                  sẽ hiển thị set_text("") cho RadComboBox
function pageLoaded() { }
function RemoveOnClickLinkButtonDisabled() {
    for (i = 0; i < document.getElementsByTagName("a").length; i++) {
        //if (document.getElementsByTagName("a")[i].href.indexOf("__doPostBack")) {
        //if (document.getElementsByTagName("a")[i].getAttribute("disabled") == "disabled") {
        if ((document.getElementsByTagName("a")[i].getAttribute("class") == "disable") || (document.getElementsByTagName("a")[i].getAttribute("disabled") == "disabled")) {
            //document.getElementsByTagName("a")[i].removeAttribute("onclick");
            if ((document.getElementsByTagName("a")[i].getAttribute("onclick") != '') && (document.getElementsByTagName("a")[i].getAttribute("onclick") != undefined)) {
                //document.getElementsByTagName("a")[i].setAttribute("myCustomAttr_click", document.getElementsByTagName("a")[i].getAttribute("onclick"));
                document.getElementsByTagName("a")[i].removeAttribute("onclick");
                document.getElementsByTagName("a")[i].setAttribute("onclick","return false;");
            }
        }
        //}
    }
}
//Không cho phép copy past textbox bị readonly
function DontPastOnTextAreaReadOnly()
{
   
    for (i = 0; i < document.getElementsByTagName("textarea").length; i++)
    {         
        if (document.getElementsByTagName("textarea")[i].readOnly == true || document.getElementsByTagName("textarea")[i].disabled == true)
        {
            document.getElementsByTagName("textarea")[i].onfocus = function () { this.blur(); };      
        }
    }
}
function allReady() {


}

var arrDefaultTotalItem_Init = new Array();
var arrDefaultTotalItem_LI_Init = new Array();
var arrDefaultTotalItem_A_Init = new Array();
var sum_span = 0, sum_li = 0, sum_a = 0;

function pageLoad() {

    // Sử dụng try... catch vì có form không sử dụng control Telerik
    // thì Telerik.Web.UI sẽ bị undefined
    try {
        allReady_FormPage();
    }
    catch (e) { }
    try {
        var menu = $find("Top1_TLR_Menu_iHRPMenu");
        try{/*LamNT22-09122014-Bẫy lỗi cho formpage, vì formpage không có Top1_TLR_Menu_iHRPMenu*/
            var totalItems = menu.get_items().get_count();
            var _span = 0, _li = 0, _a = 0;

            for (var i = 0; i < totalItems; i++) {
                var span = menu.get_items().getItem(i).get_textElement();
                arrDefaultTotalItem_Init[i] = span.offsetWidth;
                var li = menu.get_items().getItem(i).get_element();
                var a = menu.get_items().getItem(i).get_linkElement();
                arrDefaultTotalItem_LI_Init[i] = li.offsetWidth;
                arrDefaultTotalItem_A_Init[i] = a.offsetWidth;

                _span = _span + span.offsetWidth;
                _li = _li + li.offsetWidth;
                _a = _a + a.offsetWidth;
            }
            
            sum_span = _span;
            sum_li = _li;
            sum_a = _a;
            
            //alert(sum_span);
            //alert(sum_li);
            //alert(sum_a);

            if (_li > 1024) {
                document.getElementById("Top1_TLR_Menu_iHRPMenu").style.width = (_li + 13) + 'px';
                document.getElementById("Top1_TLR_Menu_iHRPMenu").style.marginLeft = '-' + (((_li + 13) - 1024) / 2) + 'px';
                document.getElementById("Top1_TLR_Menu_iHRPMenu").style.marginRight = '-' + (((_li + 13) - 1024) / 2) + 'px';
            }
            else
            {
                document.getElementById("Top1_TLR_Menu_iHRPMenu").style.width = '1024px';
            }

            StretchMenu2();
            /*
            var ua_ = navigator.userAgent.toLowerCase();
            if (ua_.indexOf("msie") != -1) {
                StretchMenu();
            }
            else {
                StretchMenu1();
            }*/
        }catch (err) { }
        // Lấy về tất cả các RadComboBox trên form
        var comboBoxesOnPage = Telerik.Web.UI.RadComboBox.ComboBoxes;
        // Duyệt qua tất cả các RadComboBox và add các sự kiện OnClientBlur, OnClientTextChange, OnClientFocus, OnClientSelectedIndexChanged
        for (var ix = 0; ix < comboBoxesOnPage.length; ix++) {
            comboBoxesOnPage[ix].get_items(); //force Item initialization
            comboBoxesOnPage[ix].add_onClientBlur(OnClientBlur); // OnClientBlur
            comboBoxesOnPage[ix].add_textChange(OnClientBlur); // OnClientTextChange
            comboBoxesOnPage[ix].add_onClientFocus(OnFocus); // OnClientFocus
            comboBoxesOnPage[ix].add_selectedIndexChanged(OnSelectedIndexChanged); // OnClientSelectedIndexChanged
            comboBoxesOnPage[ix].add_itemsRequested(OnItemsLoaded);
            comboBoxesOnPage[ix].add_dropDownOpened(OnItemsLoaded);
        }
    }
    catch (err) { }

    try {
        pageLoaded();
    }
    catch (err) { }

    try {
        allReady();        
    }
    catch (err) { }

    try {
        allReady_Top1();
    }
    catch (err) { }
    //disable cac link button
    RemoveOnClickLinkButtonDisabled();
    DontPastOnTextAreaReadOnly();
}

function allReady_FormPage() {
}
function StretchMenu1() {
    try {
        var menu = $find("Top1_TLR_Menu_iHRPMenu");
        var width = menu.get_element().offsetWidth - 10; //
        var singleItemLength = Math.floor(width / menu.get_items().get_count()) - 1 + "px";
        //alert(singleItemLength);
        var singleItemLength_ = Math.floor(width / menu.get_items().get_count()) - 1;

        var singleItemLengthForLinkAndSpanElements = Math.floor(width / menu.get_items().get_count()) - 23 + "px";
        var singleItemLengthForLinkAndSpanElements_ = Math.floor(width / menu.get_items().get_count()) - 23;

        for (var i = 0; i < menu.get_items().get_count(); i++) {
            var li = menu.get_items().getItem(i).get_element();
            var span = menu.get_items().getItem(i).get_textElement();
            var a = menu.get_items().getItem(i).get_linkElement();
            li.style.width = arrDefaultTotalItem_LI_Init[i];
            span.style.width = arrDefaultTotalItem_Init[i];
            a.style.width = arrDefaultTotalItem_A_Init[i];
        }

        var temp = 0;
        for (var i = 0; i < menu.get_items().get_count(); i++) {
            var li = menu.get_items().getItem(i).get_element();
            if (li.offsetWidth > singleItemLength_) {
                temp = temp + li.offsetWidth - singleItemLength_;
            }
        }
        //alert("width: " + width + " - temp: " + temp);
        width = width - temp;
        singleItemLengthForLinkAndSpanElements_ = Math.floor(width / menu.get_items().get_count()) - 23;
        singleItemLength_ = Math.floor(width / menu.get_items().get_count()) - 1;
        singleItemLength = Math.floor(width / menu.get_items().get_count()) - 1 + "px";
        singleItemLengthForLinkAndSpanElements = Math.floor(width / menu.get_items().get_count()) - 23 + "px";

        //alert(singleItemLength + " : " + singleItemLengthForLinkAndSpanElements);
        // due to incorrect rounding;    
        // You may need to subtract a larger number depending on    
        // the skin that you are using.     
        for (var i = 0; i < menu.get_items().get_count(); i++) {
            var li = menu.get_items().getItem(i).get_element();
            var a = menu.get_items().getItem(i).get_linkElement();
            var span = menu.get_items().getItem(i).get_textElement();
            //alert("li: " + li.offsetWidth + " - a: " + a.offsetWidth + " - span: " + span.offsetWidth);
            if (singleItemLengthForLinkAndSpanElements_ > a.offsetWidth) {
                a.style.width = singleItemLengthForLinkAndSpanElements;
            }
            if (singleItemLengthForLinkAndSpanElements_ > span.offsetWidth) {
                span.style.width = singleItemLengthForLinkAndSpanElements;
            }
            if (singleItemLength_ > span.offsetWidth) {
                li.style.width = singleItemLength;
            }
        }
    }
    catch (e) { }

    try {
        clearTimeout(t);
    }
    catch (e) { }
}

function StretchMenu() {
    try {
        var menu = $find("Top1_TLR_Menu_iHRPMenu");
        var totalItems = menu.get_items().get_count();
        var defaultTotalItemsWidth = 0;
        var currentWidth = menu.get_element().offsetWidth;
        //alert(currentWidth);
        //if(currentWidth > 1047) currentWidth = 1050; // fix width
        //currentWidth = 1000;
        var arrDefaultTotalItem = new Array();

        for (var i = 0; i < totalItems; i++) {
            var span = menu.get_items().getItem(i).get_textElement();
            span.style.width = arrDefaultTotalItem_Init[i] + "px";
        }

        for (var i = 0; i < totalItems; i++) {
            var span = menu.get_items().getItem(i).get_textElement();

            defaultTotalItemsWidth = defaultTotalItemsWidth + span.offsetWidth;
            var a = menu.get_items().getItem(i).get_linkElement();
            a.style.width = span.offsetWidth;
            arrDefaultTotalItem[i] = span.offsetWidth;
        }

        var notMatchWidth = currentWidth - defaultTotalItemsWidth - totalItems - 3;

        var minItemWidth = 0;
        var indexOfMinItemWidth = 0;
        var tempItemWidth = 0;

        if ((defaultTotalItemsWidth > 0) && (defaultTotalItemsWidth < currentWidth)) {
            while (notMatchWidth > 0) {
                minItemWidth = arrDefaultTotalItem[0];
                indexOfMinItemWidth = 0;

                for (var i = 1; i < totalItems; i++) {
                    tempItemWidth = arrDefaultTotalItem[i];
                    if (minItemWidth > tempItemWidth) {
                        indexOfMinItemWidth = i;
                        minItemWidth = tempItemWidth;
                    }
                }
                var a = menu.get_items().getItem(indexOfMinItemWidth).get_linkElement();
                a.style.width = (parseInt(minItemWidth) + 1) + "px";
                arrDefaultTotalItem[indexOfMinItemWidth] = parseInt(minItemWidth) + 1;
                notMatchWidth = notMatchWidth - 1;
                // canh giua text với span
                var span = menu.get_items().getItem(indexOfMinItemWidth).get_textElement();
                span.style.width = (parseInt(minItemWidth) + 1) + "px";
                // end   
            }
        }
    }
    catch (e) { }

    try {
        clearTimeout(t);
    }
    catch (e) { }
}

function StretchMenu2() {
    try {
        var menu = $find("Top1_TLR_Menu_iHRPMenu");
        var currentWidth = menu.get_element().offsetWidth;
        var totalItems = menu.get_items().get_count();
        var Add_span = Math.floor((currentWidth - sum_span - 10) / totalItems);
        var Add_li = Math.floor((currentWidth - sum_li - 10) / totalItems);
        var Add_a = Math.floor((currentWidth - sum_a - 10) / totalItems);
        
        //alert(currentWidth);
        //alert(sum_span);
        //alert(Add_span);
        //alert(Add_li);
        //alert(Add_a);
        //alert(totalItems);
        
        for (var i = 0; i < totalItems; i++) {
            var span = menu.get_items().getItem(i).get_textElement();
            var d_span = arrDefaultTotalItem_Init[i] + Add_span;
            span.style.width = d_span + "px";

            var li = menu.get_items().getItem(i).get_element();
            var d_li = arrDefaultTotalItem_LI_Init[i] + Add_li;
            li.style.width = d_li + "px";

            var a = menu.get_items().getItem(i).get_linkElement();
            var d_a = arrDefaultTotalItem_A_Init[i] + Add_a;
            a.style.width = d_a + "px";
        }
    }
    catch (e) {  }
}

// Lấy về TypeOfRCB, DataTextField, DataValueField của RCB
// return a$b$c$d trong đó a: TypeOfRCB, b: DataTextFieldName, c: DataValueFieldName, d: RelatedID Name được sử dụng trong điều kiện where
function GetParamsRCBByRCBClientID(comboID) {

    // JobTitle Related
    if ((comboID.indexOf("cboLSJobTitleID_Related") >= 0)) {
        return "72$Name$ID";
    }
    // JobTitle
    if ((comboID.indexOf("JobTitle") >= 0)
        || (comboID.indexOf("Position") >= 0)
        ) {
        return "1$Name$ID";
    }
    // End JobTitle

    //Hospital
    if (comboID.indexOf("Hospital") >= 0 || comboID.indexOf("PlaceExamining") >= 0 || comboID.indexOf("TreatmentPlace") >= 0) {
        return "55$Name$ID";
    }
    //End Hospital

    //Contract Type
    if (comboID.indexOf("ContractType") >= 0) {
        return "56$Name$ID";
    }
    //End Contract Type

    //Relationship
    if (comboID.indexOf("Relationship") >= 0) {
        return "57$Name$ID";
    }
    //End Relationship

    //StatusChange
    if (comboID.indexOf("StatusChange") >= 0) {
        return "58$Name$ID";
    }
    //End StatusChange

    //Loại nhân viên
    if (comboID.indexOf("LoaiNhanVien") >= 0) {
        return "59$Name$ID";
    }
    //End Loại nhân viên

    // Location
    if (comboID.indexOf("Location") >= 0) {
        return "2$Name$ID";
    }
    // Location

    // Org
    if (comboID.indexOf("Company") >= 0) {
        if (comboID.indexOf("CompanyAll") >= 0)
            return "48$Name$ID";
        else
            return "3$Name$ID";
    }

    if (comboID.indexOf("Level1") >= 0 & comboID.indexOf("LSHLevel1ID") < 0) {
        if (comboID.indexOf("Level1All") >= 0)
            return "49$Name$LSLevel1ID";
        else
            return "4$Name$LSLevel1ID";
    }

    if (comboID.indexOf("Level2") >= 0 & comboID.indexOf("LSHLevel2ID") < 0) {
        if (comboID.indexOf("Level2All") >= 0)
            return "50$Name$LSLevel2ID";
        else
            return "5$Name$LSLevel2ID";
    }

    if (comboID.indexOf("Level3") >= 0 & comboID.indexOf("LSHLevel3ID") < 0) {
        if (comboID.indexOf("Level3All") >= 0)
            return "51$Name$LSLevel3ID";
        else
            return "6$Name$LSLevel3ID";
    }
    if (comboID.indexOf("Level4") >= 0 & comboID.indexOf("LSHLevel4ID") < 0) {
        if (comboID.indexOf("LSLevel4IDAll") >= 0)
            return "105$Name$LSLevel4ID";
        else
            return "81$Name$LSLevel4ID";
    }
    if (comboID.indexOf("Level5") >= 0 & comboID.indexOf("LSHLevel5ID") < 0) {
        if (comboID.indexOf("LSLevel5IDAll") >= 0)
            return "106$Name$LSLevel5ID";
        else
            return "82$Name$LSLevel5ID";
    }
    if (comboID.indexOf("Level6") >= 0 & comboID.indexOf("LSHLevel6ID") < 0) {
        if (comboID.indexOf("LSLevel6IDAll") >= 0)
            return "107$Name$LSLevel6ID";
        else
            return "83$Name$LSLevel6ID";
    }
    if (comboID.indexOf("Level7") >= 0) {
        if (comboID.indexOf("LSLevel7IDAll") >= 0)
            return "108$Name$LSLevel7ID";
        else
            return "84$Name$LSLevel7ID";
    }
    if (comboID.indexOf("Level8") >= 0) {
        if (comboID.indexOf("LSLevel8IDAll") >= 0)
            return "109$Name$LSLevel8ID";
        else
            return "85$Name$LSLevel8ID";
    }
    if (comboID.indexOf("Level9") >= 0) {
        if (comboID.indexOf("LSLevel9IDAll") >= 0)
            return "110$Name$LSLevel9ID";
        else
            return "86$Name$LSLevel9ID";
    }
    //HLevel
    if (comboID.indexOf("LSHLevel1ID") >= 0) {
        return "137$Name$LSHLevel1ID";
    }
    if (comboID.indexOf("LSHLevel2ID") >= 0) {
        return "138$Name$LSHLevel2ID";
    }
    if (comboID.indexOf("LSHLevel3ID") >= 0) {
        return "139$Name$LSHLevel3ID";
    }
    if (comboID.indexOf("LSHLevel4ID") >= 0) {
        return "140$Name$LSHLevel4ID";
    }
    if (comboID.indexOf("LSHLevel5ID") >= 0) {
        return "141$Name$LSHLevel5ID";
    }
    if (comboID.indexOf("LSHLevel6ID") >= 0) {
        return "142$Name$LSHLevel6ID";
    }

    // End Org

    // Province
    if (comboID.indexOf("cboBorn_LSProvinceID") >= 0) {
        return "7$Name$ID";
    }

    if (comboID.indexOf("cboNative_LSProvinceID") >= 0) {
        return "7$Name$ID";
    }

    if (comboID.indexOf("cboP_LSProvinceID") >= 0) {
        return "7$Name$ID";
    }

    if (comboID.indexOf("cboT_LSProvinceID") >= 0) {
        return "7$Name$ID";
    }
    // End Province

    // District
    if (comboID.indexOf("cboP_District") >= 0) {
        return "8$Name$ID";
    }

    if (comboID.indexOf("cboT_District") >= 0) {
        return "8$Name$ID";
    }

    if (comboID.indexOf("CboT_District_") >= 0) {
        return "8$Name$ID";
    }
    // End District

    // Bank
    if (comboID.indexOf("cboLSBankID") >= 0) {
        return "9$Name$ID";
    }

    if (comboID.indexOf("cboLSBankBranchID") >= 0) {
        return "10$Name$ID";
    }

    // Template LinkServer
    if (comboID.indexOf("cboLSTemplateLinkServerID") >= 0) {
        return "101$Name$ID";
    }

    if (comboID.indexOf("cboLSTypeDataLinkServerID") >= 0) {
        return "102$Name$ID";
    }

    // Nhóm Chi Phi Hanh Chinh
    if (comboID.indexOf("cboLSNhomChiPhiHanhChinhID") >= 0) {
        return "87$Name$ID";
    }

    // Loai san pham
    if (comboID.indexOf("cboLSLoaiSanPhamID") >= 0) {
        return "103$Name$ID";
    }
    if (comboID.indexOf("cboLSCongDoanSXID") >= 0) {
        return "104$Name$ID";
    }

    if (comboID.indexOf("cboOpenAPPPeriod") >= 0) {
        return "100$Name$ID";
    }
    // End Bank

    // DanhMuc
    if (comboID.indexOf("cboMaDanhMuc1") >= 0) {
        return "16$Name$ID";
    }

    if (comboID.indexOf("cboMaDanhMuc2") >= 0) {
        return "17$Name$ID";
    }

    if (comboID.indexOf("cboMaDanhMuc3") >= 0) {
        return "18$Name$ID";
    }

    if (comboID.indexOf("cboMaDanhMuc4") >= 0) {
        return "19$Name$ID";
    }

    if (comboID.indexOf("cboMaDanhMuc5") >= 0) {
        return "20$Name$ID";
    }
    // End DanhMuc

    //    // QualifiMajor
    //    if(comboID.indexOf("cboLSQualifiMajorID1") >= 0)
    //    {
    //        return "14$Name$ID";
    //    }
    //    
    //    if(comboID.indexOf("cboLSQualifiMajorID2") >= 0)
    //    {
    //        return "15$Name$ID";
    //    }
    //    // end QualifiMajor

    // School
    if (comboID.indexOf("cboLSSchoolID") >= 0) {
        return "11$Name$ID";
    }
    // End School

    // Faculty
    if (comboID.indexOf("cboLSFacultyID") >= 0) {
        return "12$Name$ID";
    }
    // End Faculty
    // MajorLevel
    if (comboID.indexOf("cboLSMajorLevelID") >= 0) {
        return "13$Name$ID";
    }
    // End MajorLevel
    // LS_tblQualifiMajor
    if (comboID.indexOf("cboLSProfessionalLevelID") >= 0) {
        return "47$Name$ID";
    }
    // End LS_tblQualifiMajor
    // RecruitSourceType (Loại nguồn tuyển dụng)
    if (comboID.indexOf("cboLoaiNguonTuyenDung") >= 0) {
        return "53$Name$ID";
    }
    //End RecruitSourceType
    // RecruitSource (Nguồn tuyển dụng)
    if (comboID.indexOf("cboNguonTuyenDung") >= 0) {
        return "54$Name$ID";
    }
    //YCTD ALL
    if (comboID.indexOf("cboDemandIDAll") >= 0) {
        return "59$Name$ID";
    }
    //ProjectID
    if (comboID.indexOf("cboProjectID") >= 0) {
        return "60$Name$ID";
    }

    //ProjectID
    if (comboID.indexOf("cboProjectTournamentID") >= 0) {
        return "61$Name$ID";
    }

    //APP Year
    if (comboID.indexOf("cboYear") >= 0) {
        return "73$Name$ID";
    }

    //APP Period
    if (comboID.indexOf("cboAPPPeriod") >= 0) {
        return "74$Name$ID";
    }

    //APP Subject
    if (comboID.indexOf("cboAPPSubject") >= 0) {
        return "75$Name$ID";
    }

    //JobCode
    if (comboID.indexOf("cboLSJobCodeID") >= 0) {
        return "63$Name$ID";
    }
    //JobCodeGroup
    if (comboID.indexOf("cboLSJobCodeGroupID") >= 0) {
        return "65$Name$ID";
    }

    //JobType
    if (comboID.indexOf("cboLSJobTypeID") >= 0) {
        return "70$Name$ID";
    }

    //Dự án
    if (comboID.indexOf("cboLSProjectList") >= 0) {
        return "135$Name$ID";
    }
    //Lệnh sản xuất
    if (comboID.indexOf("cboLSLenhSanXuat") >= 0) {
        return "136$Name$ID";
    }

    //Chức vụ
    if (comboID.indexOf("cboLSChucVuID") >= 0) {
        return "71$Name$ID";
    }

    //Chức danh
    if (comboID.indexOf("cboLSJobTitleID_Related") >= 0) {
        return "72$Name$ID";
    }

    //Nhóm công việc
    if (comboID.indexOf("cboLSNhomNoiDungCVID") >= 0) {
        return "113$Name$ID";
    }

    //Loại công việc
    if (comboID.indexOf("cboLSLoaiNoiDungCVID") >= 0) {
        return "114$Name$ID";
    }


    if (comboID.indexOf("cboLSTrainingRangeID") >= 0) {
        return "66$Name$ID";
    }
    if (comboID.indexOf("cboLoaiNguoiDung") >= 0) {
        return "67$Name$ID";
    }
    if (comboID.indexOf("cboNhomNguoiDung") >= 0) {
        return "68$Name$ID";
    }
    if (comboID.indexOf("cboLSProfessionalLevelTypeID") >= 0) {
        return "69$Name$ID";
    }
    // Nhóm kỹ năng
    if (comboID.indexOf("cboLSSkillGroupID") >= 0) {
        return "76$Name$ID";
    }

    if (comboID.indexOf("cboLSSkillTypeID") >= 0) {
        return "77$Name$ID";
    }

    if (comboID.indexOf("cboLSEmpSkillID") >= 0) {
        return "78$Name$ID";
    }

    if (comboID.indexOf("cboTournamentSubjectID") >= 0) {
        return "79$Name$ID";
    }

    if (comboID.indexOf("cboTournamentIntContentID") >= 0) {
        return "80$Name$ID";
    }

    if (comboID.indexOf("cboLSDKHoNV") >= 0) {
        return "64$EmpName$EmpID";
    }
    if (comboID.indexOf("cboLSBangLuongID") >= 0) {
        return "111$Name$ID";
    }
    if (comboID.indexOf("cboLSBangLuongMemID") >= 0) {
        return "112$Name$ID";
    }
    if (comboID.indexOf("cboLSNgheNghiepID") >= 0) {
        return "125$Name$ID";
    }
    if (comboID.indexOf("cboLSLinhVucKinhTeID") >= 0) {
        return "126$Name$ID";
    }
    if (comboID.indexOf("cboLSLoaiHinhCoSoID") >= 0) {
        return "127$Name$ID";
    }
    if (comboID.indexOf("cboChucDanhDuAn") >= 0) {
        return "151$Name$ID";
    }
    if (comboID.indexOf("cboProjectVersionID") >= 0) {
        return "152$Name$ID";
    }
    //lucnns
    if ((comboID.indexOf("cboLSTrainingTopicID") >= 0)) {
        return "92$Name$ID";
    }
    ///////Phuong/Xa//////////
     if (comboID.indexOf("cboP_Ward") >= 0) {
        return "154$Name$ID";
    }
    if (comboID.indexOf("cboT_Ward") >= 0) {
        return "155$Name$ID";
    }
    //////Phuong/Xa//////////
    if (comboID.indexOf("cboNam") >= 0) {
        return "156$Name$ID";
    }
    if (comboID.indexOf("cboAPPKyDanhGiaHanhViID") >= 0) {
        return "157$Name$ID";
    }
     if (comboID.indexOf("cboNamKH") >= 0) {
        return "158$Name$ID";
    }
    if (comboID.indexOf("cboKyKeHoachPhatTrienBanThanID") >= 0) {
        return "159$Name$ID";
    }
    return "";
}